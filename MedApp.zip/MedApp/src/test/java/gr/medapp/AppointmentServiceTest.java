package gr.medapp;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import gr.medapp.dao.AppointmentDAO;
import gr.medapp.dao.Database;
import gr.medapp.dao.DoctorDAO;
import gr.medapp.dao.PatientDAO;
import gr.medapp.dao.WorkingHoursDAO;
import gr.medapp.model.Appointment;
import gr.medapp.model.Doctor;
import gr.medapp.model.Patient;
import gr.medapp.service.AppointmentService;
import gr.medapp.service.AuthService;
import gr.medapp.service.DoctorService;
import gr.medapp.service.ValidationException;
import gr.medapp.util.AmkaValidator;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.ZoneId;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

/** Έλεγχοι ολοκλήρωσης με πραγματική (προσωρινή) βάση SQLite. Εκτέλεση: mvn test */
class AppointmentServiceTest {
    // Δευτέρα 09/11/2026 15:00
    private static final Clock CLOCK = Clock.fixed(LocalDateTime.of(2026, 11, 9, 15, 0)
            .atZone(ZoneId.systemDefault()).toInstant(), ZoneId.systemDefault());

    @TempDir
    Path tmp;

    private AuthService auth;
    private DoctorService doctors;
    private AppointmentService appointments;
    private Patient patient;
    private Doctor doctor;

    @BeforeEach
    void setUp() throws Exception {
        Path file = tmp.resolve("test.db");
        Files.deleteIfExists(file);
        Database db = new Database(file.toString());
        db.initialize();
        auth = new AuthService(new PatientDAO(db), CLOCK);
        doctors = new DoctorService(new DoctorDAO(db), new gr.medapp.dao.VisitReasonDAO(db));
        appointments = new AppointmentService(new AppointmentDAO(db), new WorkingHoursDAO(db), CLOCK);
        patient = auth.register("01019000015", "Κώστας", "Δοκιμαστικός", "", "",
                "demo123".toCharArray(), "demo123".toCharArray());
        // Παπαδόπουλος: Δευτέρα, Τετάρτη, Παρασκευή 09:00-15:00 → 09:00, 10:30, 12:00, 13:30
        doctor = doctors.findDoctors("Παθολόγος", java.util.List.of("Αθήνα")).get(0);
    }

    @Test
    void amkaValidation() {
        assertTrue(AmkaValidator.isValid("01019000015"));
        assertFalse(AmkaValidator.isValid("01019000016"));
        assertFalse(AmkaValidator.isValid("abc"));
    }

    @Test
    void loginRequiresCorrectPassword() {
        assertEquals("01019000015", auth.login("01019000015", "demo123".toCharArray()).getAmka());
        assertThrows(ValidationException.class, () -> auth.login("01019000015", "wrong".toCharArray()));
    }

    @Test
    void searchBySpecialtyAndArea() {
        assertTrue(doctors.getSpecialties().contains("Καρδιολόγος"));
        assertTrue(doctors.getAreas("Παθολόγος").contains("Περιστέρι"));
        assertEquals("Παπαδόπουλος", doctor.getLastName());
    }

    @Test
    void bookCancelAndRebook() {
        LocalDate wednesday = LocalDate.of(2026, 11, 11);
        int before = appointments.getAvailableSlots(doctor, wednesday).size();
        Appointment a = appointments.book(patient, doctor, wednesday, LocalTime.of(9, 0), "Πυρετός");
        assertEquals(4, before);
        assertEquals(before - 1, appointments.getAvailableSlots(doctor, wednesday).size());
        assertThrows(ValidationException.class,
                () -> appointments.book(patient, doctor, wednesday, LocalTime.of(9, 0), "Ξανά"));

        appointments.cancel(patient, a.getId());
        assertEquals(before, appointments.getAvailableSlots(doctor, wednesday).size());
        appointments.book(patient, doctor, wednesday, LocalTime.of(9, 0), "Νέα κράτηση");
    }

    @Test
    void rejectsPastTimesAndEmptyReason() {
        assertThrows(ValidationException.class,
                () -> appointments.book(patient, doctor, LocalDate.of(2026, 11, 9), LocalTime.of(9, 0), "x"));
        assertThrows(ValidationException.class,
                () -> appointments.book(patient, doctor, LocalDate.of(2026, 11, 11), LocalTime.of(9, 0), " "));
    }

    @Test
    void searchInSeveralAreasAtOnce() {
        java.util.List<Doctor> both = doctors.findDoctors("Οφθαλμίατρος", java.util.List.of("Αθήνα", "Πειραιάς"));
        assertEquals(2, both.size());
        assertEquals(1, doctors.findDoctors("Οφθαλμίατρος", java.util.List.of("Πειραιάς")).size());
        assertThrows(ValidationException.class, () -> doctors.findDoctors("Οφθαλμίατρος", java.util.List.of()));
        assertTrue(appointments.findNextAvailable(both.get(0)).isPresent());
    }

    @Test
    void visitReasonsThreePlusOther() {
        java.util.List<String> reasons = doctors.getVisitReasons(doctor);
        assertEquals(4, reasons.size());
        assertEquals(DoctorService.OTHER_REASON, reasons.get(3));
        assertEquals(reasons.get(0), doctors.resolveReason(reasons.get(0), "αγνοείται"));
        assertEquals("Πόνος στο αυτί", doctors.resolveReason(DoctorService.OTHER_REASON, "  Πόνος στο αυτί "));
        assertThrows(ValidationException.class, () -> doctors.resolveReason(DoctorService.OTHER_REASON, " "));
        assertThrows(ValidationException.class, () -> doctors.resolveReason(null, ""));
    }

    @Test
    void fourNinetyMinuteAppointmentsPerDay() {
        LocalDate wednesday = LocalDate.of(2026, 11, 11);
        java.util.List<LocalTime> times = new java.util.ArrayList<>();
        appointments.getAvailableSlots(doctor, wednesday).forEach(s -> times.add(s.getTime()));
        assertEquals(java.util.List.of(LocalTime.of(9, 0), LocalTime.of(10, 30), LocalTime.of(12, 0),
                LocalTime.of(13, 30)), times);
        Patient other = auth.register("15059501237", "Άννα", "Β", "", "", "abcdef".toCharArray(), "abcdef".toCharArray());
        appointments.book(patient, doctor, wednesday, LocalTime.of(9, 0), "Α");
        appointments.book(other, doctor, wednesday, LocalTime.of(10, 30), "Β");
        appointments.book(patient, doctor, wednesday, LocalTime.of(12, 0), "Γ");
        appointments.book(other, doctor, wednesday, LocalTime.of(13, 30), "Δ");
        // 4 ραντεβού → η ημέρα είναι πλήρης
        assertTrue(appointments.getAvailableSlots(doctor, wednesday).isEmpty());
        assertThrows(ValidationException.class,
                () -> appointments.book(patient, doctor, wednesday, LocalTime.of(13, 30), "Ε"));
    }

    @Test
    void availabilityLevels() {
        assertEquals(gr.medapp.model.AvailabilityLevel.NONE, AppointmentService.classify(40, 0, 0));
        assertEquals(gr.medapp.model.AvailabilityLevel.PARTIAL, AppointmentService.classify(40, 5, 4));
        assertEquals(gr.medapp.model.AvailabilityLevel.PARTIAL, AppointmentService.classify(40, 30, 2));
        assertEquals(gr.medapp.model.AvailabilityLevel.AVAILABLE, AppointmentService.classify(40, 30, 6));
        assertEquals(gr.medapp.model.AvailabilityLevel.PARTIAL, AppointmentService.classify(17, 17, 4)); // μόνο Σάββατα
        assertEquals(gr.medapp.model.AvailabilityLevel.AVAILABLE, appointments.getAvailabilityLevel(doctor));
    }

    @Test
    void bulkCancelIsAllOrNothing() {
        Appointment a = appointments.book(patient, doctor, LocalDate.of(2026, 11, 11), LocalTime.of(9, 0), "Α");
        Appointment b = appointments.book(patient, doctor, LocalDate.of(2026, 11, 11), LocalTime.of(10, 30), "Β");
        Appointment c = appointments.book(patient, doctor, LocalDate.of(2026, 11, 16), LocalTime.of(12, 0), "Γ");
        appointments.cancel(patient, c.getId());
        // το c είναι ήδη ακυρωμένο → δεν ακυρώνεται κανένα
        assertThrows(ValidationException.class,
                () -> appointments.cancelAll(patient, java.util.List.of(a.getId(), c.getId())));
        assertEquals(2, appointments.getWeeklyAppointments(patient, LocalDate.of(2026, 11, 11)).stream()
                .filter(x -> x.getStatus() == gr.medapp.model.AppointmentStatus.ACTIVE).count());
        assertEquals(2, appointments.cancelAll(patient, java.util.List.of(a.getId(), b.getId())));
        assertEquals(0, appointments.getWeeklyAppointments(patient, LocalDate.of(2026, 11, 11)).stream()
                .filter(x -> x.getStatus() == gr.medapp.model.AppointmentStatus.ACTIVE).count());
    }

    @Test
    void weeklyAndMonthlyViews() {
        appointments.book(patient, doctor, LocalDate.of(2026, 11, 11), LocalTime.of(9, 0), "Α");
        appointments.book(patient, doctor, LocalDate.of(2026, 11, 16), LocalTime.of(10, 30), "Β");
        appointments.book(patient, doctor, LocalDate.of(2026, 11, 30), LocalTime.of(12, 0), "Γ");
        assertEquals(1, appointments.getWeeklyAppointments(patient, LocalDate.of(2026, 11, 13)).size());
        assertEquals(3, appointments.getMonthlyAppointments(patient, YearMonth.of(2026, 11)).size());
    }
}
