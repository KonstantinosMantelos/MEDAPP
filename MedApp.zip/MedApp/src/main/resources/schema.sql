-- Σχήμα βάσης δεδομένων MedApp (SQLite)

CREATE TABLE IF NOT EXISTS doctors (
    amka        TEXT PRIMARY KEY CHECK (length(amka) = 11),
    first_name  TEXT NOT NULL,
    last_name   TEXT NOT NULL,
    specialty   TEXT NOT NULL,
    phone       TEXT NOT NULL,
    email       TEXT NOT NULL,
    area        TEXT NOT NULL,
    address     TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS working_hours (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    doctor_amka  TEXT NOT NULL REFERENCES doctors(amka) ON DELETE CASCADE,
    day_of_week  INTEGER NOT NULL CHECK (day_of_week BETWEEN 1 AND 7),
    start_time   TEXT NOT NULL,
    end_time     TEXT NOT NULL,
    slot_minutes INTEGER NOT NULL DEFAULT 30 CHECK (slot_minutes > 0)
);

CREATE TABLE IF NOT EXISTS patients (
    amka          TEXT PRIMARY KEY CHECK (length(amka) = 11),
    first_name    TEXT NOT NULL,
    last_name     TEXT NOT NULL,
    phone         TEXT,
    email         TEXT,
    password_hash TEXT NOT NULL,
    salt          TEXT NOT NULL,
    created_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS appointments (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_amka  TEXT NOT NULL REFERENCES patients(amka),
    doctor_amka   TEXT NOT NULL REFERENCES doctors(amka),
    appt_date     TEXT NOT NULL,
    appt_time     TEXT NOT NULL,
    reason        TEXT NOT NULL,
    status        TEXT NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'CANCELLED')),
    created_at    TEXT NOT NULL
);

-- Ένας ιατρός δεν μπορεί να έχει δύο ενεργά ραντεβού την ίδια ώρα
CREATE UNIQUE INDEX IF NOT EXISTS ux_doctor_slot
    ON appointments(doctor_amka, appt_date, appt_time) WHERE status = 'ACTIVE';

-- Ένας ασθενής δεν μπορεί να έχει δύο ενεργά ραντεβού την ίδια ώρα
CREATE UNIQUE INDEX IF NOT EXISTS ux_patient_slot
    ON appointments(patient_amka, appt_date, appt_time) WHERE status = 'ACTIVE';

CREATE INDEX IF NOT EXISTS ix_doctor_search ON doctors(specialty, area);
CREATE INDEX IF NOT EXISTS ix_appt_patient_date ON appointments(patient_amka, appt_date);

-- Οι 3 προκαθορισμένοι λόγοι επίσκεψης κάθε ιατρού (ο ασθενής μπορεί να διαλέξει και «Άλλο»)
CREATE TABLE IF NOT EXISTS visit_reasons (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    doctor_amka  TEXT NOT NULL REFERENCES doctors(amka) ON DELETE CASCADE,
    reason       TEXT NOT NULL,
    sort_order   INTEGER NOT NULL,
    UNIQUE (doctor_amka, reason)
);
