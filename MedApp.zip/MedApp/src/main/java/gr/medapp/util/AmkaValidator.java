package gr.medapp.util;

/**
 * Έλεγχος εγκυρότητας ΑΜΚΑ: 11 ψηφία, τα 6 πρώτα είναι ημερομηνία (ΗΗΜΜΕΕ)
 * και το τελευταίο είναι ψηφίο ελέγχου κατά τον αλγόριθμο Luhn.
 */
public final class AmkaValidator {
    private AmkaValidator() { }

    public static boolean isValid(String amka) {
        if (amka == null || !amka.matches("\\d{11}")) {
            return false;
        }
        int day = Integer.parseInt(amka.substring(0, 2));
        int month = Integer.parseInt(amka.substring(2, 4));
        if (day < 1 || day > 31 || month < 1 || month > 12) {
            return false;
        }
        return luhn(amka);
    }

    static boolean luhn(String digits) {
        int sum = 0;
        for (int i = 0; i < digits.length(); i++) {
            int d = digits.charAt(digits.length() - 1 - i) - '0';
            if (i % 2 == 1) {
                d *= 2;
                if (d > 9) {
                    d -= 9;
                }
            }
            sum += d;
        }
        return sum % 10 == 0;
    }
}
