package gr.medapp.util;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.time.temporal.TemporalAdjusters;
import java.util.Locale;

/** Βοηθητικές μέθοδοι ημερομηνιών (εβδομάδα Δευτέρα–Κυριακή, ελληνική μορφοποίηση). */
public final class DateUtils {
    public static final Locale GREEK = Locale.forLanguageTag("el-GR");
    public static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    public static final DateTimeFormatter DAY_DATE = DateTimeFormatter.ofPattern("EEE dd/MM/yyyy", GREEK);
    public static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");

    private DateUtils() { }

    public static LocalDate startOfWeek(LocalDate any) {
        return any.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
    }

    public static LocalDate endOfWeek(LocalDate any) {
        return startOfWeek(any).plusDays(6);
    }

    public static String formatMonth(YearMonth ym) {
        String name = ym.getMonth().getDisplayName(TextStyle.FULL_STANDALONE, GREEK);
        return Character.toUpperCase(name.charAt(0)) + name.substring(1) + " " + ym.getYear();
    }

    public static String formatWeek(LocalDate any) {
        return startOfWeek(any).format(DATE) + " – " + endOfWeek(any).format(DATE);
    }
}
