package gr.medapp.model;

/** Ιατρός εγγεγραμμένος στην εφαρμογή. */
public class Doctor {
    private final String amka;
    private final String firstName;
    private final String lastName;
    private final String specialty;
    private final String phone;
    private final String email;
    private final String area;
    private final String address;

    public Doctor(String amka, String firstName, String lastName, String specialty,
                  String phone, String email, String area, String address) {
        this.amka = amka;
        this.firstName = firstName;
        this.lastName = lastName;
        this.specialty = specialty;
        this.phone = phone;
        this.email = email;
        this.area = area;
        this.address = address;
    }

    public String getAmka() { return amka; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getSpecialty() { return specialty; }
    public String getPhone() { return phone; }
    public String getEmail() { return email; }
    public String getArea() { return area; }
    public String getAddress() { return address; }

    public String getFullName() { return lastName + " " + firstName; }

    /** Στοιχεία επικοινωνίας σε μία γραμμή. */
    public String getContactInfo() { return phone + " · " + email; }

    @Override
    public String toString() { return getFullName() + " (" + specialty + ", " + area + ")"; }
}
