package gr.medapp.model;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/** Ωράριο ιατρείου για μία ημέρα της εβδομάδας. */
public class WorkingHours {
    private final String doctorAmka;
    private final DayOfWeek dayOfWeek;
    private final LocalTime startTime;
    private final LocalTime endTime;
    private final int slotMinutes;

    public WorkingHours(String doctorAmka, DayOfWeek dayOfWeek, LocalTime startTime,
                        LocalTime endTime, int slotMinutes) {
        this.doctorAmka = doctorAmka;
        this.dayOfWeek = dayOfWeek;
        this.startTime = startTime;
        this.endTime = endTime;
        this.slotMinutes = slotMinutes;
    }

    public String getDoctorAmka() { return doctorAmka; }
    public DayOfWeek getDayOfWeek() { return dayOfWeek; }
    public LocalTime getStartTime() { return startTime; }
    public LocalTime getEndTime() { return endTime; }
    public int getSlotMinutes() { return slotMinutes; }

    /** Οι ώρες έναρξης όλων των χρονοθυρίδων του ωραρίου. */
    public List<LocalTime> generateSlotTimes() {
        List<LocalTime> times = new ArrayList<>();
        LocalTime t = startTime;
        while (!t.plusMinutes(slotMinutes).isAfter(endTime)) {
            times.add(t);
            t = t.plusMinutes(slotMinutes);
        }
        return times;
    }
}
