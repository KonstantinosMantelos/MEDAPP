package gr.medapp.model;

import java.time.LocalDate;
import java.time.LocalTime;

/** Χρονοθυρίδα ιατρού (ημέρα + ώρα) και αν είναι ελεύθερη. */
public class TimeSlot {
    private final LocalDate date;
    private final LocalTime time;
    private final boolean available;

    public TimeSlot(LocalDate date, LocalTime time, boolean available) {
        this.date = date;
        this.time = time;
        this.available = available;
    }

    public LocalDate getDate() { return date; }
    public LocalTime getTime() { return time; }
    public boolean isAvailable() { return available; }

    @Override
    public String toString() { return time + (available ? "" : " (κλεισμένο)"); }
}
