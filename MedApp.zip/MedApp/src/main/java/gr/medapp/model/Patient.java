package gr.medapp.model;

import java.time.LocalDateTime;

/** Ασθενής-χρήστης. Ταυτοποιείται με τον ΑΜΚΑ του. */
public class Patient {
    private final String amka;
    private final String firstName;
    private final String lastName;
    private final String phone;
    private final String email;
    private final String passwordHash;
    private final String salt;
    private final LocalDateTime createdAt;

    public Patient(String amka, String firstName, String lastName, String phone, String email,
                   String passwordHash, String salt, LocalDateTime createdAt) {
        this.amka = amka;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.email = email;
        this.passwordHash = passwordHash;
        this.salt = salt;
        this.createdAt = createdAt;
    }

    public String getAmka() { return amka; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getPhone() { return phone; }
    public String getEmail() { return email; }
    public String getPasswordHash() { return passwordHash; }
    public String getSalt() { return salt; }
    public LocalDateTime getCreatedAt() { return createdAt; }

    public String getFullName() { return firstName + " " + lastName; }

    @Override
    public String toString() { return getFullName() + " [" + amka + "]"; }
}
