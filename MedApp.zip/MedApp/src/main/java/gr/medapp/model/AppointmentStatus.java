package gr.medapp.model;

/**
 * Κατάσταση ραντεβού. Στη βάση αποθηκεύονται μόνο οι ACTIVE και CANCELLED·
 * η COMPLETED προκύπτει όταν ένα ενεργό ραντεβού έχει περάσει.
 */
public enum AppointmentStatus {
    ACTIVE("Ενεργό"),
    CANCELLED("Ακυρωμένο"),
    COMPLETED("Ολοκληρωμένο");

    private final String label;

    AppointmentStatus(String label) { this.label = label; }

    public String getLabel() { return label; }

    @Override
    public String toString() { return label; }
}
