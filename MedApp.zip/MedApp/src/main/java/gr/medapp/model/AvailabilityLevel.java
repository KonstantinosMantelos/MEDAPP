package gr.medapp.model;

/** Συνολική διαθεσιμότητα ιατρού για τις επόμενες ημέρες, όπως εμφανίζεται στον ασθενή. */
public enum AvailabilityLevel {
    /** Αρκετές ελεύθερες ώρες σε αρκετές ημέρες (πράσινο). */
    AVAILABLE("Διαθεσιμότητα"),
    /** Λίγες ελεύθερες ώρες ή λίγες ημέρες (κίτρινο). */
    PARTIAL("Μερική διαθεσιμότητα"),
    /** Καμία ελεύθερη ώρα (κόκκινο). */
    NONE("Καμία διαθεσιμότητα");

    private final String label;

    AvailabilityLevel(String label) { this.label = label; }

    public String getLabel() { return label; }

    @Override
    public String toString() { return label; }
}
