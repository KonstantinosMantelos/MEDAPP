package gr.medapp.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

/** Ραντεβού ασθενή με ιατρό. */
public class Appointment {
    private int id;
    private final String patientAmka;
    private final Doctor doctor;
    private final LocalDate date;
    private final LocalTime time;
    private final String reason;
    private AppointmentStatus status;
    private final LocalDateTime createdAt;

    public Appointment(int id, String patientAmka, Doctor doctor, LocalDate date, LocalTime time,
                       String reason, AppointmentStatus status, LocalDateTime createdAt) {
        this.id = id;
        this.patientAmka = patientAmka;
        this.doctor = doctor;
        this.date = date;
        this.time = time;
        this.reason = reason;
        this.status = status;
        this.createdAt = createdAt;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getPatientAmka() { return patientAmka; }
    public Doctor getDoctor() { return doctor; }
    public LocalDate getDate() { return date; }
    public LocalTime getTime() { return time; }
    public String getReason() { return reason; }
    public AppointmentStatus getStatus() { return status; }
    public LocalDateTime getCreatedAt() { return createdAt; }

    public LocalDateTime getDateTime() { return LocalDateTime.of(date, time); }

    /** Ακύρωση: επιτρέπεται μόνο από την κατάσταση ACTIVE. */
    public void cancel() {
        if (status != AppointmentStatus.ACTIVE) {
            throw new IllegalStateException("Μόνο ενεργό ραντεβού μπορεί να ακυρωθεί.");
        }
        status = AppointmentStatus.CANCELLED;
    }

    /** Η κατάσταση όπως εμφανίζεται στον χρήστη τη στιγμή {@code now}. */
    public AppointmentStatus getEffectiveStatus(LocalDateTime now) {
        if (status == AppointmentStatus.ACTIVE && !getDateTime().isAfter(now)) {
            return AppointmentStatus.COMPLETED;
        }
        return status;
    }

    /** Μπορεί να ακυρωθεί αν είναι ενεργό και δεν έχει ακόμη έρθει η ώρα του. */
    public boolean isCancellable(LocalDateTime now) {
        return getEffectiveStatus(now) == AppointmentStatus.ACTIVE;
    }
}
