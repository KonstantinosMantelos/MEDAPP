package gr.medapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/** Πρόσβαση στον πίνακα visit_reasons (προκαθορισμένοι λόγοι επίσκεψης ανά ιατρό). */
public class VisitReasonDAO {
    static final String SQL_BY_DOCTOR = "SELECT reason FROM visit_reasons WHERE doctor_amka = ? ORDER BY sort_order";

    private final Database db;

    public VisitReasonDAO(Database db) { this.db = db; }

    public List<String> findByDoctor(String doctorAmka) {
        try (Connection c = db.getConnection(); PreparedStatement ps = c.prepareStatement(SQL_BY_DOCTOR)) {
            ps.setString(1, doctorAmka);
            List<String> list = new ArrayList<>();
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(rs.getString(1));
                }
            }
            return list;
        } catch (SQLException e) {
            throw new DataAccessException("Αποτυχία ανάγνωσης λόγων επίσκεψης", e);
        }
    }
}
