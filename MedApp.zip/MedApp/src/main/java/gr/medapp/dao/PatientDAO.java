package gr.medapp.dao;

import gr.medapp.model.Patient;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Optional;

/** Πρόσβαση στον πίνακα patients. */
public class PatientDAO {
    static final String SQL_INSERT = "INSERT INTO patients (amka, first_name, last_name, phone, email, password_hash, salt, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    static final String SQL_BY_AMKA = "SELECT * FROM patients WHERE amka = ?";

    private final Database db;

    public PatientDAO(Database db) { this.db = db; }

    public boolean exists(String amka) {
        return findByAmka(amka).isPresent();
    }

    public void insert(Patient p) {
        try (Connection c = db.getConnection(); PreparedStatement ps = c.prepareStatement(SQL_INSERT)) {
            ps.setString(1, p.getAmka());
            ps.setString(2, p.getFirstName());
            ps.setString(3, p.getLastName());
            ps.setString(4, p.getPhone());
            ps.setString(5, p.getEmail());
            ps.setString(6, p.getPasswordHash());
            ps.setString(7, p.getSalt());
            ps.setString(8, p.getCreatedAt().toString());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DataAccessException("Αποτυχία εγγραφής ασθενή", e);
        }
    }

    public Optional<Patient> findByAmka(String amka) {
        try (Connection c = db.getConnection(); PreparedStatement ps = c.prepareStatement(SQL_BY_AMKA)) {
            ps.setString(1, amka);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return Optional.empty();
                }
                return Optional.of(new Patient(rs.getString("amka"), rs.getString("first_name"),
                        rs.getString("last_name"), rs.getString("phone"), rs.getString("email"),
                        rs.getString("password_hash"), rs.getString("salt"),
                        LocalDateTime.parse(rs.getString("created_at"))));
            }
        } catch (SQLException e) {
            throw new DataAccessException("Αποτυχία ανάγνωσης ασθενή", e);
        }
    }
}
