package gr.medapp.dao;

/** Σφάλμα πρόσβασης στη βάση δεδομένων (τυλίγει την SQLException). */
public class DataAccessException extends RuntimeException {
    public DataAccessException(String message, Throwable cause) { super(message, cause); }
}
