package gr.medapp.dao;

import gr.medapp.model.Appointment;
import gr.medapp.model.AppointmentStatus;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** Πρόσβαση στον πίνακα appointments. */
public class AppointmentDAO {
    static final String SQL_INSERT = "INSERT INTO appointments (patient_amka, doctor_amka, appt_date, appt_time, reason, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)";
    static final String SQL_BOOKED_TIMES = "SELECT appt_time FROM appointments WHERE doctor_amka = ? AND appt_date = ? AND status = 'ACTIVE'";
    static final String SQL_PATIENT_TIMES = "SELECT appt_time FROM appointments WHERE patient_amka = ? AND appt_date = ? AND status = 'ACTIVE'";
    static final String SQL_SELECT_JOIN = "SELECT a.*, d.amka AS d_amka, d.first_name, d.last_name, d.specialty, d.phone, d.email, d.area, d.address FROM appointments a JOIN doctors d ON d.amka = a.doctor_amka ";
    static final String SQL_BY_ID = SQL_SELECT_JOIN + "WHERE a.id = ?";
    static final String SQL_BY_PATIENT_PERIOD = SQL_SELECT_JOIN + "WHERE a.patient_amka = ? AND a.appt_date BETWEEN ? AND ? ORDER BY a.appt_date, a.appt_time";
    static final String SQL_UPDATE_STATUS = "UPDATE appointments SET status = ? WHERE id = ?";

    private final Database db;

    public AppointmentDAO(Database db) { this.db = db; }

    /** Αποθηκεύει το ραντεβού και επιστρέφει τον κωδικό του. */
    public int insert(Appointment a) {
        try (Connection c = db.getConnection();
             PreparedStatement ps = c.prepareStatement(SQL_INSERT, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, a.getPatientAmka());
            ps.setString(2, a.getDoctor().getAmka());
            ps.setString(3, a.getDate().toString());
            ps.setString(4, a.getTime().toString());
            ps.setString(5, a.getReason());
            ps.setString(6, a.getStatus().name());
            ps.setString(7, a.getCreatedAt().toString());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                int id = keys.next() ? keys.getInt(1) : 0;
                a.setId(id);
                return id;
            }
        } catch (SQLException e) {
            throw new DataAccessException("Αποτυχία καταχώρησης ραντεβού", e);
        }
    }

    public List<LocalTime> findBookedTimes(String doctorAmka, LocalDate date) {
        try (Connection c = db.getConnection(); PreparedStatement ps = c.prepareStatement(SQL_BOOKED_TIMES)) {
            ps.setString(1, doctorAmka);
            ps.setString(2, date.toString());
            List<LocalTime> list = new ArrayList<>();
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(LocalTime.parse(rs.getString(1)));
                }
            }
            return list;
        } catch (SQLException e) {
            throw new DataAccessException("Αποτυχία ανάγνωσης διαθεσιμότητας", e);
        }
    }

    /** Οι ώρες έναρξης των ενεργών ραντεβού του ασθενή μια ημέρα. */
    public List<LocalTime> findPatientBookedTimes(String patientAmka, LocalDate date) {
        try (Connection c = db.getConnection(); PreparedStatement ps = c.prepareStatement(SQL_PATIENT_TIMES)) {
            ps.setString(1, patientAmka);
            ps.setString(2, date.toString());
            List<LocalTime> list = new ArrayList<>();
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(LocalTime.parse(rs.getString(1)));
                }
            }
            return list;
        } catch (SQLException e) {
            throw new DataAccessException("Αποτυχία ελέγχου ραντεβού ασθενή", e);
        }
    }

    public Optional<Appointment> findById(int id) {
        try (Connection c = db.getConnection(); PreparedStatement ps = c.prepareStatement(SQL_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(map(rs)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw new DataAccessException("Αποτυχία ανάγνωσης ραντεβού", e);
        }
    }

    public List<Appointment> findByPatientAndPeriod(String patientAmka, LocalDate from, LocalDate to) {
        try (Connection c = db.getConnection(); PreparedStatement ps = c.prepareStatement(SQL_BY_PATIENT_PERIOD)) {
            ps.setString(1, patientAmka);
            ps.setString(2, from.toString());
            ps.setString(3, to.toString());
            List<Appointment> list = new ArrayList<>();
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
            return list;
        } catch (SQLException e) {
            throw new DataAccessException("Αποτυχία ανάγνωσης ραντεβού ασθενή", e);
        }
    }

    public void updateStatus(int id, AppointmentStatus status) {
        try (Connection c = db.getConnection(); PreparedStatement ps = c.prepareStatement(SQL_UPDATE_STATUS)) {
            ps.setString(1, status.name());
            ps.setInt(2, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DataAccessException("Αποτυχία ενημέρωσης ραντεβού", e);
        }
    }

    private static Appointment map(ResultSet rs) throws SQLException {
        gr.medapp.model.Doctor doctor = new gr.medapp.model.Doctor(rs.getString("d_amka"),
                rs.getString("first_name"), rs.getString("last_name"), rs.getString("specialty"),
                rs.getString("phone"), rs.getString("email"), rs.getString("area"), rs.getString("address"));
        return new Appointment(rs.getInt("id"), rs.getString("patient_amka"), doctor,
                LocalDate.parse(rs.getString("appt_date")), LocalTime.parse(rs.getString("appt_time")),
                rs.getString("reason"), AppointmentStatus.valueOf(rs.getString("status")),
                LocalDateTime.parse(rs.getString("created_at")));
    }
}
