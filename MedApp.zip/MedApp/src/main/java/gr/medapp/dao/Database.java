package gr.medapp.dao;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/** Σύνδεση με τη βάση SQLite και αρχικοποίηση σχήματος/δεδομένων. */
public class Database {
    private final String url;

    public Database(String fileName) {
        this.url = "jdbc:sqlite:" + fileName;
    }

    public Connection getConnection() throws SQLException {
        Connection connection = DriverManager.getConnection(url);
        try (Statement st = connection.createStatement()) {
            st.execute("PRAGMA foreign_keys = ON");
        }
        return connection;
    }

    /**
     * Δημιουργεί τους πίνακες και φορτώνει ιατρούς, ωράρια και λόγους επίσκεψης.
     * Τα σενάρια δεδομένων ξανατρέχουν με ασφάλεια σε κάθε εκκίνηση (χωρίς διπλότυπα),
     * ώστε και μια παλιότερη βάση να αποκτά τους νέους ιατρούς χωρίς να χαθούν τα ραντεβού της.
     */
    public void initialize() {
        runScript("/schema.sql");
        runScript("/data.sql");
        runScript("/visit_reasons.sql");
    }

    private int countRows(String table) {
        try (Connection c = getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM " + table)) {
            return rs.next() ? rs.getInt(1) : 0;
        } catch (SQLException e) {
            throw new DataAccessException("Αποτυχία ανάγνωσης πίνακα " + table, e);
        }
    }

    private void runScript(String resource) {
        List<String> statements = loadStatements(resource);
        try (Connection c = getConnection()) {
            c.setAutoCommit(false);
            try (Statement st = c.createStatement()) {
                for (String sql : statements) {
                    st.execute(sql);
                }
                c.commit();
            } catch (SQLException e) {
                c.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw new DataAccessException("Αποτυχία εκτέλεσης " + resource, e);
        }
    }

    static List<String> loadStatements(String resource) {
        try (InputStream in = Database.class.getResourceAsStream(resource)) {
            if (in == null) {
                throw new IllegalStateException("Δεν βρέθηκε το " + resource);
            }
            StringBuilder sb = new StringBuilder();
            for (String line : new String(in.readAllBytes(), StandardCharsets.UTF_8).split("\\R")) {
                if (!line.trim().startsWith("--")) {
                    sb.append(line).append('\n');
                }
            }
            List<String> result = new ArrayList<>();
            for (String part : sb.toString().split(";")) {
                if (!part.isBlank()) {
                    result.add(part.trim());
                }
            }
            return result;
        } catch (IOException e) {
            throw new IllegalStateException("Αποτυχία ανάγνωσης " + resource, e);
        }
    }
}
