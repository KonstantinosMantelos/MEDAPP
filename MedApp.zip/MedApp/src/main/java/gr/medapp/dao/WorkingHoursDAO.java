package gr.medapp.dao;

import gr.medapp.model.WorkingHours;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/** Πρόσβαση στον πίνακα working_hours (ωράριο ιατρείου). */
public class WorkingHoursDAO {
    static final String SQL_BY_DOCTOR = "SELECT * FROM working_hours WHERE doctor_amka = ? ORDER BY day_of_week, start_time";

    private final Database db;

    public WorkingHoursDAO(Database db) { this.db = db; }

    public List<WorkingHours> findByDoctor(String doctorAmka) {
        try (Connection c = db.getConnection(); PreparedStatement ps = c.prepareStatement(SQL_BY_DOCTOR)) {
            ps.setString(1, doctorAmka);
            List<WorkingHours> list = new ArrayList<>();
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new WorkingHours(rs.getString("doctor_amka"),
                            DayOfWeek.of(rs.getInt("day_of_week")),
                            LocalTime.parse(rs.getString("start_time")),
                            LocalTime.parse(rs.getString("end_time")),
                            rs.getInt("slot_minutes")));
                }
            }
            return list;
        } catch (SQLException e) {
            throw new DataAccessException("Αποτυχία ανάγνωσης ωραρίου", e);
        }
    }
}
