package gr.medapp.dao;

import gr.medapp.model.Doctor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** Πρόσβαση στον πίνακα doctors. */
public class DoctorDAO {
    static final String SQL_SPECIALTIES = "SELECT DISTINCT specialty FROM doctors";
    static final String SQL_AREAS = "SELECT DISTINCT area FROM doctors WHERE specialty = ?";
    static final String SQL_SEARCH = "SELECT * FROM doctors WHERE specialty = ? AND area IN (%s) ORDER BY area, last_name, first_name";
    static final String SQL_BY_AMKA = "SELECT * FROM doctors WHERE amka = ?";

    private final Database db;

    public DoctorDAO(Database db) { this.db = db; }

    public List<String> findAllSpecialties() {
        return queryStrings(SQL_SPECIALTIES, null);
    }

    public List<String> findAreasBySpecialty(String specialty) {
        return queryStrings(SQL_AREAS, specialty);
    }

    /** Ιατροί μιας ειδικότητας σε μία ή περισσότερες περιοχές. */
    public List<Doctor> findBySpecialtyAndAreas(String specialty, List<String> areas) {
        if (areas == null || areas.isEmpty()) {
            return new ArrayList<>();
        }
        String sql = String.format(SQL_SEARCH, String.join(", ", java.util.Collections.nCopies(areas.size(), "?")));
        try (Connection c = db.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, specialty);
            for (int i = 0; i < areas.size(); i++) {
                ps.setString(i + 2, areas.get(i));
            }
            List<Doctor> list = new ArrayList<>();
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(map(rs));
                }
            }
            return list;
        } catch (SQLException e) {
            throw new DataAccessException("Αποτυχία αναζήτησης ιατρών", e);
        }
    }

    public Optional<Doctor> findByAmka(String amka) {
        try (Connection c = db.getConnection(); PreparedStatement ps = c.prepareStatement(SQL_BY_AMKA)) {
            ps.setString(1, amka);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(map(rs)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw new DataAccessException("Αποτυχία ανάγνωσης ιατρού", e);
        }
    }

    private List<String> queryStrings(String sql, String param) {
        try (Connection c = db.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            if (param != null) {
                ps.setString(1, param);
            }
            List<String> list = new ArrayList<>();
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(rs.getString(1));
                }
            }
            return list;
        } catch (SQLException e) {
            throw new DataAccessException("Αποτυχία ανάγνωσης λίστας", e);
        }
    }

    static Doctor map(ResultSet rs) throws SQLException {
        return new Doctor(rs.getString("amka"), rs.getString("first_name"), rs.getString("last_name"),
                rs.getString("specialty"), rs.getString("phone"), rs.getString("email"),
                rs.getString("area"), rs.getString("address"));
    }
}
