package gr.medapp;

import gr.medapp.dao.AppointmentDAO;
import gr.medapp.dao.Database;
import gr.medapp.dao.DoctorDAO;
import gr.medapp.dao.PatientDAO;
import gr.medapp.dao.VisitReasonDAO;
import gr.medapp.dao.WorkingHoursDAO;
import gr.medapp.service.AppointmentService;
import gr.medapp.service.AuthService;
import gr.medapp.service.DoctorService;
import gr.medapp.ui.MainFrame;
import gr.medapp.ui.Theme;
import java.time.Clock;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

/** Σημείο εκκίνησης: δημιουργεί βάση, DAO, υπηρεσίες και το κύριο παράθυρο. */
public final class App {
    public static final String DB_FILE = "medapp.db";
    public static final String DEMO_AMKA = "01019000015";
    public static final String DEMO_PASSWORD = "demo123";

    private App() { }

    public static void main(String[] args) {
        Theme.install();
        Clock clock = Clock.systemDefaultZone();
        Database db = new Database(args.length > 0 ? args[0] : DB_FILE);
        try {
            db.initialize();
        } catch (RuntimeException e) {
            JOptionPane.showMessageDialog(null, "Αδυναμία σύνδεσης με τη βάση: " + e.getMessage(),
                    "MedApp", JOptionPane.ERROR_MESSAGE);
            return;
        }
        PatientDAO patientDAO = new PatientDAO(db);
        AuthService authService = new AuthService(patientDAO, clock);
        DoctorService doctorService = new DoctorService(new DoctorDAO(db), new VisitReasonDAO(db));
        AppointmentService appointmentService = new AppointmentService(new AppointmentDAO(db),
                new WorkingHoursDAO(db), clock);

        if (!patientDAO.exists(DEMO_AMKA)) {
            char[] pw = DEMO_PASSWORD.toCharArray();
            authService.register(DEMO_AMKA, "Κώστας", "Δοκιμαστικός", "6900000000", "demo@medapp.example", pw, pw);
        }

        SwingUtilities.invokeLater(() ->
                new MainFrame(authService, doctorService, appointmentService).setVisible(true));
    }
}
