package gr.medapp.ui;

import gr.medapp.service.ValidationException;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.Box;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/** Κοινές βοηθητικές μέθοδοι για τις οθόνες. */
final class UiSupport {
    private UiSupport() { }

    /** Εκτελεί μια ενέργεια και δείχνει φιλικό μήνυμα αν αποτύχει. */
    static boolean run(Component parent, Runnable action) {
        try {
            action.run();
            return true;
        } catch (ValidationException e) {
            JOptionPane.showMessageDialog(parent, e.getMessage(), "Προσοχή", JOptionPane.WARNING_MESSAGE);
        } catch (RuntimeException e) {
            JOptionPane.showMessageDialog(parent, "Παρουσιάστηκε σφάλμα: " + e.getMessage(),
                    "Σφάλμα", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }

    static JLabel title(String text) {
        return Theme.label(text, Font.BOLD, 24, Theme.TEXT);
    }

    /** Προσθέτει σε κάθετη φόρμα μια ετικέτα και από κάτω το πεδίο. */
    static void addField(JPanel form, String label, JComponent field) {
        JLabel l = Theme.label(label, Font.BOLD, 13, Theme.MUTED);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        form.add(l);
        form.add(Box.createVerticalStrut(4));
        if (field instanceof JTextField) {
            ((JTextField) field).setFont(Theme.font(Font.PLAIN, 15));
        }
        field.setAlignmentX(Component.LEFT_ALIGNMENT);
        field.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        field.setPreferredSize(new Dimension(320, 36));
        form.add(field);
        form.add(Box.createVerticalStrut(12));
    }

    static void addFull(JPanel form, JComponent c) {
        c.setAlignmentX(Component.LEFT_ALIGNMENT);
        c.setMaximumSize(new Dimension(Integer.MAX_VALUE, c.getPreferredSize().height));
        form.add(c);
    }
}
