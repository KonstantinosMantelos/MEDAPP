package gr.medapp.ui;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JToggleButton;

/** Επιλέξιμο «κουμπάκι» (π.χ. ελεύθερη ώρα, εβδομάδα/μήνας). */
public class ChipButton extends JToggleButton {
    private Color selectedForeground = Color.WHITE;
    private Color normalForeground = Theme.PRIMARY;

    public ChipButton(String text) {
        super(text);
        setFont(Theme.font(Font.BOLD, 14));
        setContentAreaFilled(false);
        setFocusPainted(false);
        setBorderPainted(false);
        setOpaque(false);
        setRolloverEnabled(true);
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        setBorder(Theme.padding(8, 16));
        addItemListener(e -> updateForeground());
        updateForeground();
    }

    /** Χρώματα κειμένου για επιλεγμένη και μη επιλεγμένη κατάσταση. */
    protected void setForegrounds(Color selected, Color normal) {
        selectedForeground = selected;
        normalForeground = normal;
        updateForeground();
    }

    private void updateForeground() {
        setForeground(isSelected() ? selectedForeground : normalForeground);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int w = getWidth() - 1;
        int h = getHeight() - 1;
        if (isSelected()) {
            g2.setColor(Theme.PRIMARY);
            g2.fillRoundRect(0, 0, w, h, h, h);
        } else {
            g2.setColor(getModel().isRollover() ? Theme.PRIMARY_LIGHT : Color.WHITE);
            g2.fillRoundRect(0, 0, w, h, h, h);
            g2.setColor(new Color(0xB7CBE6));
            g2.drawRoundRect(0, 0, w, h, h, h);
        }
        g2.dispose();
        super.paintComponent(g);
    }
}
