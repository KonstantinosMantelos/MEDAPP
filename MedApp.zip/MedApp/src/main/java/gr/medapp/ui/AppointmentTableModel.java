package gr.medapp.ui;

import gr.medapp.model.Appointment;
import gr.medapp.util.DateUtils;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.table.AbstractTableModel;

/**
 * Πίνακας με τα ραντεβού του ασθενή. Σε «λειτουργία επιλογής για ακύρωση» εμφανίζεται
 * πρώτη στήλη με κουτάκι· τσεκάρονται μόνο ραντεβού που μπορούν να ακυρωθούν.
 */
public class AppointmentTableModel extends AbstractTableModel {
    private static final String[] COLUMNS = {"Ημερομηνία", "Ώρα", "Ιατρός", "Ειδικότητα", "Περιοχή", "Λόγος", "Κατάσταση"};
    private List<Appointment> appointments = new ArrayList<>();
    private LocalDateTime now = LocalDateTime.now();
    private boolean selectionMode;
    /** Τα τσεκαρισμένα, ακόμη και από άλλη εβδομάδα/μήνα που δεν φαίνεται τώρα. */
    private final Map<Integer, Appointment> checked = new LinkedHashMap<>();
    private Runnable onCheckedChanged = () -> { };

    public void setAppointments(List<Appointment> appointments, LocalDateTime now) {
        this.appointments = appointments;
        this.now = now;
        fireTableDataChanged();
    }

    public Appointment getAppointment(int row) { return appointments.get(row); }

    public boolean isSelectionMode() { return selectionMode; }

    public void setSelectionMode(boolean on) {
        selectionMode = on;
        checked.clear();
        fireTableStructureChanged();
        onCheckedChanged.run();
    }

    public void setOnCheckedChanged(Runnable r) { onCheckedChanged = r; }

    /** Στήλη όπου ξεκινούν τα στοιχεία του ραντεβού (1 όταν υπάρχει στήλη επιλογής). */
    public int offset() { return selectionMode ? 1 : 0; }

    public boolean isCheckable(int row) { return appointments.get(row).isCancellable(now); }

    public boolean isChecked(int row) { return checked.containsKey(appointments.get(row).getId()); }

    /** Τσεκάρει/ξετσεκάρει μια γραμμή, μόνο αν το ραντεβού μπορεί να ακυρωθεί. */
    public void toggle(int row) {
        if (!selectionMode || !isCheckable(row)) {
            return;
        }
        Appointment a = appointments.get(row);
        if (checked.remove(a.getId()) == null) {
            checked.put(a.getId(), a);
        }
        fireTableRowsUpdated(row, row);
        onCheckedChanged.run();
    }

    /** Τσεκάρει όλα τα ακυρώσιμα της περιόδου ή, αν είναι ήδη όλα τσεκαρισμένα, τα ξετσεκάρει. */
    public void toggleAllVisible() {
        boolean allChecked = true;
        for (int r = 0; r < appointments.size(); r++) {
            if (isCheckable(r) && !isChecked(r)) {
                allChecked = false;
            }
        }
        for (int r = 0; r < appointments.size(); r++) {
            if (isCheckable(r)) {
                Appointment a = appointments.get(r);
                if (allChecked) {
                    checked.remove(a.getId());
                } else {
                    checked.put(a.getId(), a);
                }
            }
        }
        fireTableDataChanged();
        onCheckedChanged.run();
    }

    public List<Appointment> getChecked() { return new ArrayList<>(checked.values()); }

    @Override public int getRowCount() { return appointments.size(); }
    @Override public int getColumnCount() { return COLUMNS.length + offset(); }

    @Override
    public String getColumnName(int col) {
        return selectionMode && col == 0 ? "" : COLUMNS[col - offset()];
    }

    @Override
    public Class<?> getColumnClass(int col) {
        return selectionMode && col == 0 ? Boolean.class : String.class;
    }

    @Override
    public Object getValueAt(int row, int col) {
        if (selectionMode && col == 0) {
            return isChecked(row);
        }
        Appointment a = appointments.get(row);
        switch (col - offset()) {
            case 0: return a.getDate().format(DateUtils.DAY_DATE);
            case 1: return a.getTime().format(DateUtils.TIME);
            case 2: return a.getDoctor().getFullName();
            case 3: return a.getDoctor().getSpecialty();
            case 4: return a.getDoctor().getArea();
            case 5: return a.getReason();
            default: return a.getEffectiveStatus(now).getLabel();
        }
    }
}
