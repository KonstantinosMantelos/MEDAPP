package gr.medapp.ui;

import gr.medapp.model.Patient;
import gr.medapp.service.AuthService;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/** Οθόνη εγγραφής νέου ασθενή με ΑΜΚΑ και κωδικό. */
public class RegisterPanel extends JPanel {
    private final JTextField amka = new JTextField(20);
    private final JTextField firstName = new JTextField(14);
    private final JTextField lastName = new JTextField(14);
    private final JTextField phone = new JTextField(14);
    private final JTextField email = new JTextField(14);
    private final JPasswordField password = new JPasswordField(14);
    private final JPasswordField confirm = new JPasswordField(14);

    public RegisterPanel(MainFrame frame, AuthService authService) {
        super(new BorderLayout());
        JPanel form = new JPanel();
        form.setOpaque(false);
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));

        UiSupport.addFull(form, UiSupport.title("Νέος λογαριασμός"));
        form.add(Box.createVerticalStrut(4));
        UiSupport.addFull(form, Theme.label("Τα πεδία με * είναι υποχρεωτικά", Font.PLAIN, 14, Theme.MUTED));
        form.add(Box.createVerticalStrut(18));
        UiSupport.addField(form, "ΑΜΚΑ *", amka);
        form.add(row(column("Όνομα *", firstName), column("Επώνυμο *", lastName)));
        form.add(row(column("Τηλέφωνο", phone), column("Email", email)));
        form.add(row(column("Κωδικός * (τουλ. " + AuthService.MIN_PASSWORD_LENGTH + ")", password),
                column("Επιβεβαίωση κωδικού *", confirm)));
        form.add(Box.createVerticalStrut(6));

        FlatButton submit = new FlatButton("Εγγραφή", FlatButton.Kind.PRIMARY);
        UiSupport.addFull(form, submit);
        form.add(Box.createVerticalStrut(10));
        FlatButton back = new FlatButton("Έχω ήδη λογαριασμό", FlatButton.Kind.SECONDARY);
        UiSupport.addFull(form, back);

        add(Theme.splitScreen(Theme.brandPanel("Δημιουργήστε λογαριασμό με τον ΑΜΚΑ σας μέσα σε ένα λεπτό.",
                "Ο ΑΜΚΑ σας είναι το όνομα χρήστη", "Ο κωδικός αποθηκεύεται κρυπτογραφημένος",
                "Μετά την εγγραφή μπαίνετε αμέσως"), form));

        submit.addActionListener(e -> {
            Patient[] result = new Patient[1];
            boolean ok = UiSupport.run(this, () -> result[0] = authService.register(amka.getText(),
                    firstName.getText(), lastName.getText(), phone.getText(), email.getText(),
                    password.getPassword(), confirm.getPassword()));
            if (ok) {
                JOptionPane.showMessageDialog(this, "Η εγγραφή ολοκληρώθηκε. Καλώς ήρθατε!");
                frame.showHome(result[0]);
            }
        });
        back.addActionListener(e -> frame.showLogin());
    }

    private static JPanel column(String label, JTextField field) {
        JPanel col = new JPanel();
        col.setOpaque(false);
        col.setLayout(new BoxLayout(col, BoxLayout.Y_AXIS));
        UiSupport.addField(col, label, field);
        field.setPreferredSize(new java.awt.Dimension(200, 36));
        return col;
    }

    private static JPanel row(JPanel a, JPanel b) {
        JPanel row = new JPanel(new GridLayout(1, 2, 14, 0));
        row.setOpaque(false);
        row.add(a);
        row.add(b);
        row.setAlignmentX(LEFT_ALIGNMENT);
        return row;
    }

    void reset() {
        for (JTextField f : new JTextField[]{amka, firstName, lastName, phone, email, password, confirm}) {
            f.setText("");
        }
    }
}
