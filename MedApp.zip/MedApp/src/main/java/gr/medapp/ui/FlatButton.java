package gr.medapp.ui;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JButton;

/** Επίπεδο κουμπί με στρογγυλεμένες γωνίες: κύριο (γεμάτο), δευτερεύον (περίγραμμα) ή κόκκινο. */
public class FlatButton extends JButton {
    public enum Kind { PRIMARY, SECONDARY, DANGER, ON_DARK }

    private final Kind kind;

    public FlatButton(String text, Kind kind) {
        super(text);
        this.kind = kind;
        setFont(Theme.font(Font.BOLD, 14));
        setContentAreaFilled(false);
        setFocusPainted(false);
        setBorderPainted(false);
        setOpaque(false);
        setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        setBorder(Theme.padding(9, 18));
        setRolloverEnabled(true);
        setForeground(kind == Kind.PRIMARY || kind == Kind.ON_DARK ? Color.WHITE
                : kind == Kind.DANGER ? Theme.DANGER : Theme.PRIMARY);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        boolean hover = getModel().isRollover();
        boolean pressed = getModel().isPressed();
        int w = getWidth() - 1;
        int h = getHeight() - 1;
        switch (kind) {
            case PRIMARY:
                g2.setColor(pressed ? Theme.PRIMARY_DARK.darker() : hover ? Theme.PRIMARY_DARK : Theme.PRIMARY);
                g2.fillRoundRect(0, 0, w, h, 10, 10);
                break;
            case ON_DARK:
                g2.setColor(new Color(255, 255, 255, hover ? 60 : 35));
                g2.fillRoundRect(0, 0, w, h, 10, 10);
                break;
            default:
                Color c = kind == Kind.DANGER ? Theme.DANGER : Theme.PRIMARY;
                g2.setColor(hover ? (kind == Kind.DANGER ? Theme.DANGER_LIGHT : Theme.PRIMARY_LIGHT) : Color.WHITE);
                g2.fillRoundRect(0, 0, w, h, 10, 10);
                g2.setColor(c);
                g2.drawRoundRect(0, 0, w, h, 10, 10);
        }
        if (!isEnabled()) {
            g2.setColor(new Color(255, 255, 255, 140));
            g2.fillRoundRect(0, 0, w, h, 10, 10);
        }
        g2.dispose();
        super.paintComponent(g);
    }
}
