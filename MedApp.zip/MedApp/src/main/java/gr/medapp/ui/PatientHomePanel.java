package gr.medapp.ui;

import gr.medapp.model.Patient;
import gr.medapp.service.AppointmentService;
import gr.medapp.service.DoctorService;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JPanel;

/** Αρχική οθόνη συνδεδεμένου ασθενή: μπάρα εφαρμογής και δύο ενότητες. */
public class PatientHomePanel extends JPanel {
    static final String NEW = "Νέο ραντεβού";
    static final String MINE = "Τα ραντεβού μου";

    public PatientHomePanel(MainFrame frame, Patient patient, DoctorService doctorService,
                            AppointmentService appointmentService) {
        super(new BorderLayout());
        setBackground(Theme.BACKGROUND);

        MyAppointmentsPanel myAppointments = new MyAppointmentsPanel(patient, appointmentService);
        SearchDoctorPanel search = new SearchDoctorPanel(patient, doctorService, appointmentService,
                myAppointments::refresh);
        CardLayout cards = new CardLayout();
        JPanel content = new JPanel(cards);
        content.setOpaque(false);
        content.add(search, NEW);
        content.add(myAppointments, MINE);

        JPanel bar = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setPaint(new GradientPaint(0, 0, Theme.PRIMARY, getWidth(), 0, Theme.PRIMARY_DARK));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        bar.setBorder(Theme.padding(10, 20));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        left.setOpaque(false);
        left.add(new Theme.MedicalCross(32));
        left.add(Theme.label("MedApp", Font.BOLD, 20, Color.WHITE));
        left.add(new JLabel("   "));
        ChipBar nav = new ChipBar();
        nav.add(NEW, () -> cards.show(content, NEW), true);
        nav.add(MINE, () -> {
            myAppointments.refresh();
            cards.show(content, MINE);
        }, false);
        left.add(nav);
        bar.add(left, BorderLayout.WEST);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 0));
        right.setOpaque(false);
        JLabel who = Theme.label("<html><div style='text-align:right'><b>" + patient.getFullName()
                + "</b><br><span style='font-size:9px'>ΑΜΚΑ " + patient.getAmka() + "</span></div></html>",
                Font.PLAIN, 13, Color.WHITE);
        right.add(who);
        FlatButton logout = new FlatButton("Αποσύνδεση", FlatButton.Kind.ON_DARK);
        logout.addActionListener(e -> frame.logout());
        right.add(logout);
        bar.add(right, BorderLayout.EAST);

        add(bar, BorderLayout.NORTH);
        JPanel body = new JPanel(new BorderLayout());
        body.setBackground(Theme.BACKGROUND);
        body.setBorder(BorderFactory.createEmptyBorder(16, 20, 20, 20));
        body.add(content, BorderLayout.CENTER);
        add(body, BorderLayout.CENTER);
    }

    /** Πλοήγηση με «κουμπάκια» πάνω στη μπάρα. */
    private static final class ChipBar extends JPanel {
        private final ButtonGroup group = new ButtonGroup();

        ChipBar() {
            super(new FlowLayout(FlowLayout.LEFT, 6, 0));
            setOpaque(false);
        }

        void add(String text, Runnable action, boolean selected) {
            NavButton b = new NavButton(text);
            b.setSelected(selected);
            b.addActionListener(e -> action.run());
            group.add(b);
            super.add(b);
        }
    }

    /** Κουμπί πλοήγησης: λευκό όταν είναι επιλεγμένο. */
    private static final class NavButton extends ChipButton {
        NavButton(String text) {
            super(text);
            setForegrounds(Theme.PRIMARY_DARK, Color.WHITE);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(java.awt.RenderingHints.KEY_ANTIALIASING, java.awt.RenderingHints.VALUE_ANTIALIAS_ON);
            int h = getHeight() - 1;
            if (isSelected()) {
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0, 0, getWidth() - 1, h, h, h);
            } else if (getModel().isRollover()) {
                g2.setColor(new Color(255, 255, 255, 40));
                g2.fillRoundRect(0, 0, getWidth() - 1, h, h, h);
            }
            g2.dispose();
            paintLabel(g);
        }

        private void paintLabel(Graphics g) {
            // μόνο το κείμενο, χωρίς το φόντο του ChipButton
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(java.awt.RenderingHints.KEY_TEXT_ANTIALIASING,
                    java.awt.RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setFont(getFont());
            g2.setColor(getForeground());
            java.awt.FontMetrics fm = g2.getFontMetrics();
            g2.drawString(getText(), (getWidth() - fm.stringWidth(getText())) / 2,
                    (getHeight() - fm.getHeight()) / 2 + fm.getAscent());
            g2.dispose();
        }
    }
}
