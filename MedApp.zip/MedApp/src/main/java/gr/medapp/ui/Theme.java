package gr.medapp.ui;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.GridBagLayout;
import java.awt.RenderingHints;
import java.util.Arrays;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;

/** Ενιαία οπτική ταυτότητα της εφαρμογής: χρώματα, γραμματοσειρές και έτοιμα στοιχεία. */
public final class Theme {
    public static final Color PRIMARY = new Color(0x1565C0);
    public static final Color PRIMARY_DARK = new Color(0x0D47A1);
    public static final Color PRIMARY_LIGHT = new Color(0xE3EEFB);
    public static final Color BACKGROUND = new Color(0xF3F6FA);
    public static final Color CARD = Color.WHITE;
    public static final Color BORDER = new Color(0xDCE3EC);
    public static final Color TEXT = new Color(0x1F2937);
    public static final Color MUTED = new Color(0x6B7280);
    public static final Color STRIPE = new Color(0xF7F9FC);
    public static final Color SUCCESS = new Color(0x2E7D32);
    public static final Color SUCCESS_LIGHT = new Color(0xE6F4EA);
    public static final Color DANGER = new Color(0xC62828);
    public static final Color DANGER_LIGHT = new Color(0xFDECEC);
    public static final Color NEUTRAL_LIGHT = new Color(0xEEF0F3);
    public static final Color WARNING = new Color(0x8A6100);
    public static final Color WARNING_LIGHT = new Color(0xFFF3CD);

    private static String family = Font.SANS_SERIF;

    private Theme() { }

    /** Εγκαθιστά Nimbus με την παλέτα της εφαρμογής. Καλείται πριν δημιουργηθεί οποιοδήποτε παράθυρο. */
    public static void install() {
        String[] preferred = {"Segoe UI", "Noto Sans", "DejaVu Sans", "Liberation Sans"};
        String[] available = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
        for (String f : preferred) {
            if (Arrays.asList(available).contains(f)) {
                family = f;
                break;
            }
        }
        UIManager.put("control", BACKGROUND);
        UIManager.put("nimbusBase", PRIMARY_DARK);
        UIManager.put("nimbusBlueGrey", new Color(0xC9D3E0));
        UIManager.put("nimbusFocus", PRIMARY);
        UIManager.put("nimbusSelectionBackground", PRIMARY);
        UIManager.put("nimbusSelection", PRIMARY);
        UIManager.put("text", TEXT);
        UIManager.put("defaultFont", font(Font.PLAIN, 14));
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {
            // μένει η προεπιλεγμένη εμφάνιση
        }
        UIManager.getLookAndFeelDefaults().put("defaultFont", font(Font.PLAIN, 14));
        UIManager.put("OptionPane.messageFont", font(Font.PLAIN, 14));
        UIManager.put("OptionPane.buttonFont", font(Font.PLAIN, 14));
    }

    public static Font font(int style, float size) {
        return new Font(family, style, Math.round(size));
    }

    public static JLabel label(String text, int style, float size, Color color) {
        JLabel l = new JLabel(text);
        l.setFont(font(style, size));
        l.setForeground(color);
        return l;
    }

    public static Border padding(int v, int h) {
        return BorderFactory.createEmptyBorder(v, h, v, h);
    }

    /** Λευκή κάρτα με στρογγυλεμένες γωνίες. */
    public static class Card extends JPanel {
        public Card() {
            setOpaque(false);
            setBorder(padding(20, 24));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(0, 0, 0, 14));
            g2.fillRoundRect(1, 3, getWidth() - 2, getHeight() - 3, 16, 16);
            g2.setColor(CARD);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 3, 16, 16);
            g2.setColor(BORDER);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 3, 16, 16);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    /** Πάνελ με το λογότυπο: χρωματιστό φόντο, σταυρός και σύντομη περιγραφή. */
    public static JPanel brandPanel(String subtitle, String... steps) {
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setPaint(new GradientPaint(0, 0, PRIMARY, getWidth(), getHeight(), PRIMARY_DARK));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(new Color(255, 255, 255, 18));
                g2.fillOval(getWidth() - 220, getHeight() - 220, 320, 320);
                g2.fillOval(-80, -80, 220, 220);
                g2.dispose();
            }
        };
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(padding(60, 44));
        panel.setPreferredSize(new Dimension(400, 10));

        JComponent logo = new MedicalCross(56);
        logo.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(logo);
        panel.add(Box.createVerticalStrut(20));
        JLabel name = label("MedApp", Font.BOLD, 34, Color.WHITE);
        name.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(name);
        panel.add(Box.createVerticalStrut(6));
        JLabel sub = label("<html><div style='width:220px'>" + subtitle + "</div></html>", Font.PLAIN, 15,
                new Color(0xDCE8F8));
        sub.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(sub);
        panel.add(Box.createVerticalStrut(36));
        for (int i = 0; i < steps.length; i++) {
            JPanel row = new JPanel(new BorderLayout(12, 0));
            row.setOpaque(false);
            row.setAlignmentX(Component.LEFT_ALIGNMENT);
            row.setMaximumSize(new Dimension(320, 52));
            row.add(new StepBadge(i + 1), BorderLayout.WEST);
            row.add(label("<html><div style='width:190px'>" + steps[i] + "</div></html>", Font.PLAIN, 14,
                    Color.WHITE), BorderLayout.CENTER);
            panel.add(row);
            panel.add(Box.createVerticalStrut(12));
        }
        panel.add(Box.createVerticalGlue());
        return panel;
    }

    /** Οθόνη χωρισμένη σε δύο: πάνελ λογότυπου αριστερά, φόρμα σε κάρτα δεξιά. */
    public static JPanel splitScreen(JPanel brand, JComponent form) {
        JPanel root = new JPanel(new BorderLayout());
        root.add(brand, BorderLayout.WEST);
        JPanel right = new JPanel(new GridBagLayout());
        right.setBackground(BACKGROUND);
        Card card = new Card();
        card.setLayout(new BorderLayout());
        card.add(form, BorderLayout.CENTER);
        right.add(card);
        root.add(right, BorderLayout.CENTER);
        return root;
    }

    /** Ενιαία εμφάνιση πινάκων: ψηλές γραμμές, εναλλασσόμενο φόντο, καθαρή κεφαλίδα. */
    public static void styleTable(JTable table) {
        table.setRowHeight(36);
        table.setFont(font(Font.PLAIN, 14));
        table.setShowVerticalLines(false);
        table.setShowHorizontalLines(true);
        table.setGridColor(new Color(0xEDF1F6));
        table.setSelectionBackground(PRIMARY_LIGHT);
        table.setSelectionForeground(TEXT);
        table.setFillsViewportHeight(true);
        table.setBackground(CARD);
        table.setDefaultRenderer(Object.class, new StripedRenderer());
        JTableHeader header = table.getTableHeader();
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(10, 38));
        header.setDefaultRenderer((t, value, sel, focus, row, col) -> {
            JLabel l = label(value == null ? "" : value.toString(), Font.BOLD, 13, MUTED);
            l.setOpaque(true);
            l.setBackground(new Color(0xF0F4F9));
            l.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER), padding(0, 10)));
            return l;
        });
    }

    public static JScrollPane scroll(JComponent c) {
        JScrollPane sp = new JScrollPane(c);
        sp.setBorder(BorderFactory.createLineBorder(BORDER));
        sp.getViewport().setBackground(CARD);
        return sp;
    }

    /** Φόντο γραμμής: επιλεγμένη, τσεκαρισμένη για ακύρωση ή εναλλασσόμενη. */
    static Color rowBackground(JTable t, int row, boolean selected) {
        if (t.getModel() instanceof AppointmentTableModel
                && ((AppointmentTableModel) t.getModel()).isChecked(t.convertRowIndexToModel(row))) {
            return DANGER_LIGHT;
        }
        return selected ? PRIMARY_LIGHT : (row % 2 == 0 ? CARD : STRIPE);
    }

    /** Γραμμές πίνακα με εσωτερικό περιθώριο και εναλλασσόμενο φόντο. */
    public static class StripedRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable t, Object value, boolean selected,
                                                       boolean focus, int row, int col) {
            super.getTableCellRendererComponent(t, value, selected, false, row, col);
            setBorder(padding(0, 10));
            setFont(font(Font.PLAIN, 14));
            setForeground(TEXT);
            setBackground(rowBackground(t, row, selected));
            setToolTipText(value == null ? null : value.toString());
            return this;
        }
    }

    /** Σήμανση κατάστασης ραντεβού ως χρωματιστή «ετικέτα». */
    public static class StatusRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable t, Object value, boolean selected,
                                                       boolean focus, int row, int col) {
            JPanel cell = new JPanel(new GridBagLayout());
            cell.setBackground(rowBackground(t, row, selected));
            String text = value == null ? "" : value.toString();
            Color fg = MUTED;
            Color bg = NEUTRAL_LIGHT;
            if ("Ενεργό".equals(text)) {
                fg = SUCCESS;
                bg = SUCCESS_LIGHT;
            } else if ("Ακυρωμένο".equals(text)) {
                fg = DANGER;
                bg = DANGER_LIGHT;
            }
            cell.add(new Pill(text, fg, bg));
            return cell;
        }
    }

    /** Μικρή στρογγυλεμένη ετικέτα. */
    public static class Pill extends JLabel {
        private final Color bg;

        public Pill(String text, Color fg, Color bg) {
            super(text, SwingConstants.CENTER);
            this.bg = bg;
            setFont(font(Font.BOLD, 12));
            setForeground(fg);
            setBorder(padding(3, 10));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(bg);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), getHeight(), getHeight());
            g2.dispose();
            super.paintComponent(g);
        }
    }

    /** Ιατρικός σταυρός μέσα σε κύκλο (λογότυπο). */
    public static class MedicalCross extends JComponent {
        private final int size;

        public MedicalCross(int size) {
            this.size = size;
            Dimension d = new Dimension(size, size);
            setPreferredSize(d);
            setMaximumSize(d);
            setMinimumSize(d);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(Color.WHITE);
            g2.fillOval(0, 0, size, size);
            g2.setColor(PRIMARY);
            int arm = size / 5;
            int len = size * 3 / 5;
            int o = (size - len) / 2;
            g2.fillRoundRect(o, (size - arm) / 2, len, arm, 4, 4);
            g2.fillRoundRect((size - arm) / 2, o, arm, len, 4, 4);
            g2.dispose();
        }
    }

    /** Αριθμημένος κύκλος για τα βήματα. */
    static class StepBadge extends JComponent {
        private final int n;

        StepBadge(int n) {
            this.n = n;
            setPreferredSize(new Dimension(28, 28));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            int y0 = (getHeight() - 28) / 2;
            g2.setColor(new Color(255, 255, 255, 40));
            g2.fillOval(0, y0, 28, 28);
            g2.setColor(Color.WHITE);
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawOval(0, y0, 27, 27);
            g2.setFont(font(Font.BOLD, 13));
            String s = String.valueOf(n);
            int w = g2.getFontMetrics().stringWidth(s);
            g2.drawString(s, (28 - w) / 2, y0 + 19);
            g2.dispose();
        }
    }
}
