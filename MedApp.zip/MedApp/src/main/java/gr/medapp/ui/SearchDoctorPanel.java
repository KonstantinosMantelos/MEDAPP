package gr.medapp.ui;

import gr.medapp.model.AvailabilityLevel;
import gr.medapp.model.Doctor;
import gr.medapp.model.Patient;
import gr.medapp.model.TimeSlot;
import gr.medapp.service.AppointmentService;
import gr.medapp.service.DoctorService;
import gr.medapp.util.DateUtils;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.Window;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.table.AbstractTableModel;

/**
 * Επιλογή ειδικότητας, μίας ή περισσότερων περιοχών και ιατρού.
 * Ο πίνακας δείχνει για κάθε ιατρό το επόμενο ελεύθερο ραντεβού, ώστε να συγκρίνονται περιοχές.
 */
public class SearchDoctorPanel extends JPanel {
    private final Patient patient;
    private final DoctorService doctorService;
    private final AppointmentService appointmentService;
    private final Runnable onBooked;
    private final JComboBox<String> specialtyBox = new JComboBox<>();
    private final JPanel areaChips = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
    private final List<ChipButton> areaButtons = new ArrayList<>();
    private final DoctorTableModel tableModel = new DoctorTableModel();
    private final JTable table = new JTable(tableModel);
    private final JLabel resultLabel = Theme.label(" ", Font.PLAIN, 13, Theme.MUTED);
    private final JLabel emptyLabel = Theme.label(" ", Font.PLAIN, 14, Theme.MUTED);
    private final CardLayout resultCards = new CardLayout();
    private final JPanel results = new JPanel(resultCards);

    public SearchDoctorPanel(Patient patient, DoctorService doctorService,
                             AppointmentService appointmentService, Runnable onBooked) {
        super(new BorderLayout(0, 14));
        this.patient = patient;
        this.doctorService = doctorService;
        this.appointmentService = appointmentService;
        this.onBooked = onBooked;
        setOpaque(false);

        // Κάρτα φίλτρων
        Theme.Card filters = new Theme.Card();
        filters.setLayout(new BoxLayout(filters, BoxLayout.Y_AXIS));
        add(filters, BorderLayout.NORTH);
        left(filters, Theme.label("Βρείτε ιατρό", Font.BOLD, 20, Theme.TEXT));
        filters.add(Box.createVerticalStrut(2));
        left(filters, Theme.label("Επιλέξτε ειδικότητα και μία ή περισσότερες περιοχές· τα αποτελέσματα ενημερώνονται αμέσως.",
                Font.PLAIN, 13, Theme.MUTED));
        filters.add(Box.createVerticalStrut(14));

        JPanel row = new JPanel(new BorderLayout(20, 0));
        row.setOpaque(false);
        JPanel specialty = new JPanel();
        specialty.setOpaque(false);
        specialty.setLayout(new BoxLayout(specialty, BoxLayout.Y_AXIS));
        left(specialty, Theme.label("Ειδικότητα", Font.BOLD, 13, Theme.MUTED));
        specialty.add(Box.createVerticalStrut(4));
        specialtyBox.setFont(Theme.font(Font.PLAIN, 15));
        specialtyBox.setPreferredSize(new Dimension(230, 36));
        specialtyBox.setMaximumSize(new Dimension(230, 36));
        left(specialty, specialtyBox);
        row.add(specialty, BorderLayout.WEST);

        JPanel areas = new JPanel();
        areas.setOpaque(false);
        areas.setLayout(new BoxLayout(areas, BoxLayout.Y_AXIS));
        JPanel areaHead = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        areaHead.setOpaque(false);
        areaHead.add(Theme.label("Περιοχές (πατήστε όσες θέλετε)", Font.BOLD, 13, Theme.MUTED));
        areaHead.add(Box.createHorizontalStrut(12));
        JLabel all = link("Όλες");
        JLabel none = link("Καμία");
        areaHead.add(all);
        areaHead.add(Theme.label("  ·  ", Font.PLAIN, 12, Theme.MUTED));
        areaHead.add(none);
        left(areas, areaHead);
        areas.add(Box.createVerticalStrut(4));
        areaChips.setOpaque(false);
        left(areas, areaChips);
        row.add(areas, BorderLayout.CENTER);
        left(filters, row);

        // Αποτελέσματα
        Theme.Card list = new Theme.Card();
        list.setLayout(new BorderLayout(0, 12));
        JPanel listHead = new JPanel(new BorderLayout());
        listHead.setOpaque(false);
        listHead.add(Theme.label("Ιατροί και διαθεσιμότητα", Font.BOLD, 16, Theme.TEXT), BorderLayout.WEST);
        listHead.add(resultLabel, BorderLayout.EAST);
        list.add(listHead, BorderLayout.NORTH);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        Theme.styleTable(table);
        int[] widths = {190, 100, 170, 105, 190, 170};
        for (int i = 0; i < widths.length; i++) {
            table.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        }
        table.getColumnModel().getColumn(5).setCellRenderer(new AvailabilityRenderer());
        results.setOpaque(false);
        results.add(Theme.scroll(table), "table");
        JPanel empty = new JPanel(new GridBagLayout());
        empty.setBackground(Theme.CARD);
        empty.add(emptyLabel);
        results.add(empty, "empty");
        list.add(results, BorderLayout.CENTER);

        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setOpaque(false);
        bottom.add(Theme.label("Διπλό κλικ σε ιατρό ανοίγει όλες τις ελεύθερες ώρες του", Font.PLAIN, 12, Theme.MUTED),
                BorderLayout.WEST);
        FlatButton availability = new FlatButton("Διαθεσιμότητα & κράτηση  →", FlatButton.Kind.PRIMARY);
        bottom.add(availability, BorderLayout.EAST);
        list.add(bottom, BorderLayout.SOUTH);
        add(list, BorderLayout.CENTER);

        UiSupport.run(this, () -> specialtyBox.setModel(new DefaultComboBoxModel<>(
                doctorService.getSpecialties().toArray(new String[0]))));
        specialtyBox.addActionListener(e -> loadAreas());
        all.addMouseListener(click(() -> setAllAreas(true)));
        none.addMouseListener(click(() -> setAllAreas(false)));
        availability.addActionListener(e -> openBooking());
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    openBooking();
                }
            }
        });
        loadAreas();
    }

    private static void left(JPanel parent, Component c) {
        if (c instanceof javax.swing.JComponent) {
            ((javax.swing.JComponent) c).setAlignmentX(LEFT_ALIGNMENT);
        }
        parent.add(c);
    }

    private static JLabel link(String text) {
        JLabel l = Theme.label("<html><u>" + text + "</u></html>", Font.PLAIN, 13, Theme.PRIMARY);
        l.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
        return l;
    }

    private static MouseAdapter click(Runnable r) {
        return new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                r.run();
            }
        };
    }

    /** Νέα ειδικότητα: φτιάχνει ένα κουμπάκι ανά περιοχή, όλα επιλεγμένα. */
    private void loadAreas() {
        String specialty = (String) specialtyBox.getSelectedItem();
        areaChips.removeAll();
        areaButtons.clear();
        if (specialty != null) {
            List<String>[] areas = new List[1];
            UiSupport.run(this, () -> areas[0] = doctorService.getAreas(specialty));
            if (areas[0] != null) {
                for (String area : areas[0]) {
                    ChipButton chip = new ChipButton(area);
                    chip.setSelected(true);
                    chip.addActionListener(e -> search());
                    areaButtons.add(chip);
                    areaChips.add(chip);
                }
            }
        }
        areaChips.revalidate();
        areaChips.repaint();
        search();
    }

    private void setAllAreas(boolean selected) {
        for (ChipButton b : areaButtons) {
            b.setSelected(selected);
        }
        search();
    }

    List<String> selectedAreas() {
        List<String> list = new ArrayList<>();
        for (ChipButton b : areaButtons) {
            if (b.isSelected()) {
                list.add(b.getText());
            }
        }
        return list;
    }

    private void search() {
        String specialty = (String) specialtyBox.getSelectedItem();
        List<String> areas = selectedAreas();
        List<DoctorRow> rows = new ArrayList<>();
        if (specialty != null && !areas.isEmpty()) {
            UiSupport.run(this, () -> {
                for (Doctor d : doctorService.findDoctors(specialty, areas)) {
                    rows.add(new DoctorRow(d, appointmentService.findNextAvailable(d),
                            appointmentService.getAvailabilityLevel(d)));
                }
            });
        }
        tableModel.setRows(rows);
        int n = rows.size();
        resultLabel.setText((n == 1 ? "1 ιατρός" : n + " ιατροί")
                + (areas.isEmpty() ? "" : " σε " + String.join(", ", areas)));
        emptyLabel.setText(areas.isEmpty() ? "Επιλέξτε τουλάχιστον μία περιοχή."
                : "Δεν βρέθηκαν ιατροί για αυτόν τον συνδυασμό.");
        resultCards.show(results, n == 0 ? "empty" : "table");
        if (n > 0) {
            table.setRowSelectionInterval(0, 0);
        }
    }

    private void openBooking() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Επιλέξτε πρώτα έναν ιατρό από τη λίστα.");
            return;
        }
        Doctor doctor = tableModel.getDoctor(table.convertRowIndexToModel(row));
        Window owner = SwingUtilities.getWindowAncestor(this);
        BookingDialog dialog = new BookingDialog(owner, patient, doctor, appointmentService, doctorService);
        dialog.setVisible(true);
        if (dialog.isBooked()) {
            onBooked.run();
            search();
        }
    }

    /** Ιατρός μαζί με τη διαθεσιμότητά του. */
    static final class DoctorRow {
        final Doctor doctor;
        final Optional<TimeSlot> next;
        final AvailabilityLevel level;

        DoctorRow(Doctor doctor, Optional<TimeSlot> next, AvailabilityLevel level) {
            this.doctor = doctor;
            this.next = next;
            this.level = level;
        }
    }

    /** Πίνακας ιατρών με στοιχεία και διαθεσιμότητα. */
    static class DoctorTableModel extends AbstractTableModel {
        private static final String[] COLUMNS = {"Ονοματεπώνυμο", "Περιοχή", "Διεύθυνση", "Τηλέφωνο",
                "Επόμενο ελεύθερο", "Διαθεσιμότητα"};
        private List<DoctorRow> rows = new ArrayList<>();

        void setRows(List<DoctorRow> rows) {
            this.rows = rows;
            fireTableDataChanged();
        }

        Doctor getDoctor(int row) { return rows.get(row).doctor; }

        @Override public int getRowCount() { return rows.size(); }
        @Override public int getColumnCount() { return COLUMNS.length; }
        @Override public String getColumnName(int col) { return COLUMNS[col]; }

        @Override
        public Object getValueAt(int row, int col) {
            DoctorRow r = rows.get(row);
            Doctor d = r.doctor;
            switch (col) {
                case 0: return d.getFullName();
                case 1: return d.getArea();
                case 2: return d.getAddress();
                case 3: return d.getPhone();
                case 4: return r.next.map(s -> s.getDate().format(DateUtils.DAY_DATE) + " · "
                        + s.getTime().format(DateUtils.TIME)).orElse("—");
                default: return r.level;
            }
        }
    }

    /** Διαθεσιμότητα ως χρωματιστή ετικέτα: πράσινο, κίτρινο ή κόκκινο. */
    private static final class AvailabilityRenderer extends Theme.StripedRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable t, Object value, boolean selected,
                                                       boolean focus, int row, int col) {
            JPanel cell = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
            cell.setBackground(Theme.rowBackground(t, row, selected));
            AvailabilityLevel level = value instanceof AvailabilityLevel ? (AvailabilityLevel) value : AvailabilityLevel.NONE;
            switch (level) {
                case AVAILABLE:
                    cell.add(new Theme.Pill(level.getLabel(), Theme.SUCCESS, Theme.SUCCESS_LIGHT));
                    break;
                case PARTIAL:
                    cell.add(new Theme.Pill(level.getLabel(), Theme.WARNING, Theme.WARNING_LIGHT));
                    break;
                default:
                    cell.add(new Theme.Pill(level.getLabel(), Theme.DANGER, Theme.DANGER_LIGHT));
            }
            return cell;
        }
    }
}
