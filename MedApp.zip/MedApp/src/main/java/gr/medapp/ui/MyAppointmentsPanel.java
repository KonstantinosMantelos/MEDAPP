package gr.medapp.ui;

import gr.medapp.model.Appointment;
import gr.medapp.model.AppointmentStatus;
import gr.medapp.model.Patient;
import gr.medapp.service.AppointmentService;
import gr.medapp.util.DateUtils;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;
import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;

/** Προβολή ραντεβού ανά εβδομάδα ή μήνα και ακύρωση. */
public class MyAppointmentsPanel extends JPanel {
    private final Patient patient;
    private final AppointmentService service;
    private final ChipButton weekly = new ChipButton("Εβδομάδα");
    private final ChipButton monthly = new ChipButton("Μήνας");
    private final JCheckBox showCancelled = new JCheckBox("Εμφάνιση ακυρωμένων");
    private final JLabel periodLabel = Theme.label(" ", Font.BOLD, 18, Theme.TEXT);
    private final JLabel activeCount = Theme.label("0", Font.BOLD, 26, Theme.PRIMARY);
    private final JLabel totalCount = Theme.label("0", Font.BOLD, 26, Theme.TEXT);
    private final AppointmentTableModel tableModel = new AppointmentTableModel();
    private final JTable table = new JTable(tableModel);
    private final CardLayout resultCards = new CardLayout();
    private final JPanel results = new JPanel(resultCards);
    private final CardLayout bottomCards = new CardLayout();
    private final JPanel bottomBar = new JPanel(bottomCards);
    private final JLabel selectionInfo = Theme.label(" ", Font.PLAIN, 13, Theme.MUTED);
    private final FlatButton cancelChecked = new FlatButton("Ακύρωση επιλεγμένων (0)", FlatButton.Kind.DANGER);
    private LocalDate reference;

    public MyAppointmentsPanel(Patient patient, AppointmentService service) {
        super(new BorderLayout(0, 14));
        this.patient = patient;
        this.service = service;
        this.reference = service.now().toLocalDate();
        setOpaque(false);

        // Κάρτα περιόδου
        Theme.Card top = new Theme.Card();
        top.setLayout(new BorderLayout(16, 0));
        JPanel nav = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        nav.setOpaque(false);
        ButtonGroup group = new ButtonGroup();
        group.add(weekly);
        group.add(monthly);
        weekly.setSelected(true);
        nav.add(weekly);
        nav.add(monthly);
        nav.add(Box.createHorizontalStrut(16));
        FlatButton prev = new FlatButton("‹", FlatButton.Kind.SECONDARY);
        FlatButton today = new FlatButton("Σήμερα", FlatButton.Kind.SECONDARY);
        FlatButton next = new FlatButton("›", FlatButton.Kind.SECONDARY);
        nav.add(prev);
        nav.add(today);
        nav.add(next);
        nav.add(Box.createHorizontalStrut(16));
        nav.add(periodLabel);
        top.add(nav, BorderLayout.CENTER);
        JPanel stats = new JPanel(new FlowLayout(FlowLayout.RIGHT, 22, 0));
        stats.setOpaque(false);
        stats.add(stat(activeCount, "ενεργά"));
        stats.add(stat(totalCount, "σύνολο περιόδου"));
        top.add(stats, BorderLayout.EAST);
        add(top, BorderLayout.NORTH);

        // Κάρτα πίνακα
        Theme.Card list = new Theme.Card();
        list.setLayout(new BorderLayout(0, 12));
        JPanel head = new JPanel(new BorderLayout());
        head.setOpaque(false);
        head.add(Theme.label("Τα ραντεβού μου", Font.BOLD, 16, Theme.TEXT), BorderLayout.WEST);
        showCancelled.setOpaque(false);
        showCancelled.setFont(Theme.font(Font.PLAIN, 13));
        head.add(showCancelled, BorderLayout.EAST);
        list.add(head, BorderLayout.NORTH);

        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        Theme.styleTable(table);
        applyColumns();
        tableModel.setOnCheckedChanged(this::updateSelectionBar);
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = table.rowAtPoint(e.getPoint());
                if (row >= 0 && tableModel.isSelectionMode()) {
                    tableModel.toggle(table.convertRowIndexToModel(row));
                }
            }
        });
        results.setOpaque(false);
        results.add(Theme.scroll(table), "table");
        JPanel empty = new JPanel(new GridBagLayout());
        empty.setBackground(Theme.CARD);
        empty.add(Theme.label("Δεν έχετε ραντεβού σε αυτή την περίοδο.", Font.PLAIN, 14, Theme.MUTED));
        results.add(empty, "empty");
        list.add(results, BorderLayout.CENTER);

        // Κανονική λειτουργία: ακύρωση ενός ή είσοδος σε πολλαπλή επιλογή
        JPanel normalBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        normalBar.setOpaque(false);
        FlatButton multi = new FlatButton("Επιλογή πολλών για ακύρωση", FlatButton.Kind.SECONDARY);
        FlatButton cancel = new FlatButton("Ακύρωση επιλεγμένου ραντεβού", FlatButton.Kind.DANGER);
        normalBar.add(multi);
        normalBar.add(cancel);
        // Λειτουργία επιλογής: κουτάκια μόνο σε ραντεβού που μπορούν να ακυρωθούν
        JPanel selectBar = new JPanel(new BorderLayout());
        selectBar.setOpaque(false);
        selectBar.add(selectionInfo, BorderLayout.WEST);
        JPanel selectButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        selectButtons.setOpaque(false);
        FlatButton all = new FlatButton("Επιλογή όλων της περιόδου", FlatButton.Kind.SECONDARY);
        FlatButton exit = new FlatButton("Άκυρο", FlatButton.Kind.SECONDARY);
        selectButtons.add(all);
        selectButtons.add(exit);
        selectButtons.add(cancelChecked);
        selectBar.add(selectButtons, BorderLayout.EAST);
        bottomBar.setOpaque(false);
        bottomBar.add(normalBar, "normal");
        bottomBar.add(selectBar, "select");
        list.add(bottomBar, BorderLayout.SOUTH);
        multi.addActionListener(e -> setSelectionMode(true));
        exit.addActionListener(e -> setSelectionMode(false));
        all.addActionListener(e -> tableModel.toggleAllVisible());
        cancelChecked.addActionListener(e -> cancelChecked());
        add(list, BorderLayout.CENTER);

        weekly.addActionListener(e -> refresh());
        monthly.addActionListener(e -> refresh());
        showCancelled.addActionListener(e -> refresh());
        prev.addActionListener(e -> move(-1));
        next.addActionListener(e -> move(1));
        today.addActionListener(e -> {
            reference = service.now().toLocalDate();
            refresh();
        });
        cancel.addActionListener(e -> cancelSelected());
        refresh();
    }

    private static JPanel stat(JLabel number, String caption) {
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);
        number.setHorizontalAlignment(JLabel.RIGHT);
        p.add(number, BorderLayout.NORTH);
        JLabel c = Theme.label(caption, Font.PLAIN, 12, Theme.MUTED);
        c.setHorizontalAlignment(JLabel.RIGHT);
        p.add(c, BorderLayout.SOUTH);
        return p;
    }

    private void move(int direction) {
        reference = weekly.isSelected() ? reference.plusWeeks(direction) : reference.plusMonths(direction);
        refresh();
    }

    /** Επαναφόρτωση της τρέχουσας περιόδου. */
    public void refresh() {
        UiSupport.run(this, () -> {
            List<Appointment> list;
            if (weekly.isSelected()) {
                list = service.getWeeklyAppointments(patient, reference);
                periodLabel.setText(DateUtils.formatWeek(reference));
            } else {
                YearMonth month = YearMonth.from(reference);
                list = service.getMonthlyAppointments(patient, month);
                periodLabel.setText(DateUtils.formatMonth(month));
            }
            LocalDateTime now = service.now();
            List<Appointment> shown = new ArrayList<>();
            int active = 0;
            for (Appointment a : list) {
                AppointmentStatus st = a.getEffectiveStatus(now);
                if (st == AppointmentStatus.ACTIVE) {
                    active++;
                }
                if (st != AppointmentStatus.CANCELLED || showCancelled.isSelected()) {
                    shown.add(a);
                }
            }
            tableModel.setAppointments(shown, now);
            activeCount.setText(String.valueOf(active));
            totalCount.setText(String.valueOf(shown.size()));
            resultCards.show(results, shown.isEmpty() ? "empty" : "table");
        });
    }

    /** Ορίζει πλάτη και εμφάνιση στηλών (ξανά, όταν μπαίνει/βγαίνει η στήλη επιλογής). */
    private void applyColumns() {
        int off = tableModel.offset();
        if (off == 1) {
            table.getColumnModel().getColumn(0).setCellRenderer(new CheckRenderer());
            table.getColumnModel().getColumn(0).setPreferredWidth(44);
            table.getColumnModel().getColumn(0).setMaxWidth(44);
        }
        table.getColumnModel().getColumn(6 + off).setCellRenderer(new Theme.StatusRenderer());
        int[] widths = {130, 60, 170, 110, 90, 280, 110};
        for (int i = 0; i < widths.length; i++) {
            table.getColumnModel().getColumn(i + off).setPreferredWidth(widths[i]);
        }
    }

    private void setSelectionMode(boolean on) {
        tableModel.setSelectionMode(on);
        applyColumns();
        table.clearSelection();
        table.setRowSelectionAllowed(!on);
        bottomCards.show(bottomBar, on ? "select" : "normal");
    }

    private void updateSelectionBar() {
        int n = tableModel.getChecked().size();
        cancelChecked.setText("Ακύρωση επιλεγμένων (" + n + ")");
        cancelChecked.setEnabled(n > 0);
        selectionInfo.setText(n == 0
                ? "Πατήστε σε ενεργά ραντεβού για να τα τσεκάρετε."
                : "Επιλέχθηκαν " + n + " ραντεβού για ακύρωση.");
    }

    private void cancelChecked() {
        List<Appointment> chosen = tableModel.getChecked();
        if (chosen.isEmpty()) {
            return;
        }
        StringBuilder msg = new StringBuilder("Θα ακυρωθούν " + chosen.size() + " ραντεβού:\n\n");
        List<Integer> ids = new ArrayList<>();
        for (Appointment a : chosen) {
            ids.add(a.getId());
            msg.append("• ").append(a.getDate().format(DateUtils.DAY_DATE)).append(' ')
                    .append(a.getTime().format(DateUtils.TIME)).append(" – ")
                    .append(a.getDoctor().getFullName()).append('\n');
        }
        msg.append("\nΗ ενέργεια δεν αναιρείται. Συνέχεια;");
        int answer = JOptionPane.showConfirmDialog(this, msg.toString(), "Επιβεβαίωση ακύρωσης",
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        int[] done = new int[1];
        if (answer == JOptionPane.YES_OPTION && UiSupport.run(this, () -> done[0] = service.cancelAll(patient, ids))) {
            JOptionPane.showMessageDialog(this, "Ακυρώθηκαν " + done[0] + " ραντεβού.");
            setSelectionMode(false);
            refresh();
        }
    }

    /** Κουτάκι επιλογής· στα ραντεβού που δεν ακυρώνονται δεν εμφανίζεται. */
    private final class CheckRenderer implements javax.swing.table.TableCellRenderer {
        private final JCheckBox box = new JCheckBox();
        private final JPanel cell = new JPanel(new GridBagLayout());

        CheckRenderer() {
            box.setOpaque(false);
            cell.add(box);
        }

        @Override
        public java.awt.Component getTableCellRendererComponent(JTable t, Object value, boolean selected,
                                                                boolean focus, int row, int col) {
            int r = t.convertRowIndexToModel(row);
            boolean checkable = tableModel.isCheckable(r);
            box.setVisible(checkable);
            box.setSelected(Boolean.TRUE.equals(value));
            cell.setBackground(Theme.rowBackground(t, row, selected));
            return cell;
        }
    }

    private void cancelSelected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Επιλέξτε ένα ραντεβού από τον πίνακα "
                    + "ή πατήστε «Επιλογή πολλών για ακύρωση».");
            return;
        }
        Appointment a = tableModel.getAppointment(table.convertRowIndexToModel(row));
        int answer = JOptionPane.showConfirmDialog(this,
                "Ακύρωση του ραντεβού με " + a.getDoctor().getFullName() + "\nστις "
                        + a.getDate().format(DateUtils.DAY_DATE) + " " + a.getTime().format(DateUtils.TIME) + ";",
                "Επιβεβαίωση ακύρωσης", JOptionPane.YES_NO_OPTION);
        if (answer == JOptionPane.YES_OPTION && UiSupport.run(this, () -> service.cancel(patient, a.getId()))) {
            JOptionPane.showMessageDialog(this, "Το ραντεβού ακυρώθηκε.");
            refresh();
        }
    }
}
