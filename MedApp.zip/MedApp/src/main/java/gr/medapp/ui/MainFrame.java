package gr.medapp.ui;

import gr.medapp.model.Patient;
import gr.medapp.service.AppointmentService;
import gr.medapp.service.AuthService;
import gr.medapp.service.DoctorService;
import java.awt.CardLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;

/** Κύριο παράθυρο: εναλλάσσει τις οθόνες σύνδεσης, εγγραφής και ασθενή. */
public class MainFrame extends JFrame {
    private static final String LOGIN = "login";
    private static final String REGISTER = "register";
    private static final String HOME = "home";

    private final CardLayout cards = new CardLayout();
    private final JPanel content = new JPanel(cards);
    private final DoctorService doctorService;
    private final AppointmentService appointmentService;
    private final LoginPanel loginPanel;
    private final RegisterPanel registerPanel;
    private PatientHomePanel homePanel;

    public MainFrame(AuthService authService, DoctorService doctorService, AppointmentService appointmentService) {
        super("MedApp – Ραντεβού με Ιατρούς");
        this.doctorService = doctorService;
        this.appointmentService = appointmentService;
        this.loginPanel = new LoginPanel(this, authService);
        this.registerPanel = new RegisterPanel(this, authService);
        content.add(loginPanel, LOGIN);
        content.add(registerPanel, REGISTER);
        setContentPane(content);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1150, 720);
        setMinimumSize(new java.awt.Dimension(980, 640));
        setLocationRelativeTo(null);
        showLogin();
    }

    void showLogin() {
        loginPanel.reset();
        cards.show(content, LOGIN);
    }

    void showRegister() {
        registerPanel.reset();
        cards.show(content, REGISTER);
    }

    /** Μετά από επιτυχή σύνδεση ή εγγραφή. */
    void showHome(Patient patient) {
        if (homePanel != null) {
            content.remove(homePanel);
        }
        homePanel = new PatientHomePanel(this, patient, doctorService, appointmentService);
        content.add(homePanel, HOME);
        cards.show(content, HOME);
    }

    void logout() {
        if (homePanel != null) {
            content.remove(homePanel);
            homePanel = null;
        }
        showLogin();
    }
}
