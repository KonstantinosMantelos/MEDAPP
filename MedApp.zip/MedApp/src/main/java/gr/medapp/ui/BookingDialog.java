package gr.medapp.ui;

import gr.medapp.model.Appointment;
import gr.medapp.model.Doctor;
import gr.medapp.model.Patient;
import gr.medapp.model.TimeSlot;
import gr.medapp.service.AppointmentService;
import gr.medapp.service.DoctorService;
import gr.medapp.util.DateUtils;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Window;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ListCellRenderer;
import javax.swing.ListSelectionModel;

/** Διαθεσιμότητα ιατρού (ημέρες/ώρες) και κράτηση ραντεβού με λόγο. */
public class BookingDialog extends JDialog {
    private static final DateTimeFormatter DAY_NAME = DateTimeFormatter.ofPattern("EEEE", DateUtils.GREEK);

    private final Patient patient;
    private final Doctor doctor;
    private final AppointmentService service;
    private final DoctorService doctorService;
    private final ButtonGroup reasonGroup = new ButtonGroup();
    private final JScrollPane otherScroll;
    private String selectedReason;
    private final DefaultListModel<DayItem> dayModel = new DefaultListModel<>();
    private final JList<DayItem> dayList = new JList<>(dayModel);
    private final JPanel slotGrid = new JPanel(new GridLayout(0, 4, 8, 8));
    private final JLabel slotTitle = Theme.label(" ", Font.BOLD, 15, Theme.TEXT);
    private final JTextArea reasonArea = new JTextArea(3, 40);
    private ButtonGroup slotGroup = new ButtonGroup();
    private TimeSlot selectedSlot;
    private boolean booked;

    public BookingDialog(Window owner, Patient patient, Doctor doctor, AppointmentService service,
                         DoctorService doctorService) {
        super(owner, "Κράτηση ραντεβού – " + doctor.getFullName(), ModalityType.APPLICATION_MODAL);
        this.patient = patient;
        this.doctor = doctor;
        this.service = service;
        this.doctorService = doctorService;

        JPanel root = new JPanel(new BorderLayout(0, 14));
        root.setBackground(Theme.BACKGROUND);
        root.setBorder(Theme.padding(16, 18));

        // Στοιχεία ιατρού
        Theme.Card info = new Theme.Card();
        info.setLayout(new BorderLayout(14, 0));
        info.setBorder(Theme.padding(14, 18));
        info.add(new Theme.MedicalCross(44), BorderLayout.WEST);
        JPanel text = new JPanel();
        text.setOpaque(false);
        text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
        text.add(Theme.label(doctor.getFullName(), Font.BOLD, 18, Theme.TEXT));
        text.add(Theme.label(doctor.getSpecialty() + " · " + doctor.getAddress() + ", " + doctor.getArea(),
                Font.PLAIN, 13, Theme.MUTED));
        text.add(Theme.label(doctor.getContactInfo(), Font.PLAIN, 13, Theme.MUTED));
        info.add(text, BorderLayout.CENTER);
        root.add(info, BorderLayout.NORTH);

        // Ημέρες και ώρες
        JPanel middle = new JPanel(new BorderLayout(14, 0));
        middle.setOpaque(false);
        Theme.Card daysCard = new Theme.Card();
        daysCard.setLayout(new BorderLayout(0, 8));
        daysCard.setBorder(Theme.padding(14, 14));
        daysCard.add(Theme.label("1. Ημέρα", Font.BOLD, 15, Theme.TEXT), BorderLayout.NORTH);
        dayList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        dayList.setCellRenderer(new DayRenderer());
        dayList.setFixedCellHeight(52);
        JScrollPane days = new JScrollPane(dayList);
        days.setBorder(BorderFactory.createLineBorder(Theme.BORDER));
        daysCard.add(days, BorderLayout.CENTER);
        daysCard.setPreferredSize(new java.awt.Dimension(270, 10));
        middle.add(daysCard, BorderLayout.WEST);

        Theme.Card slotsCard = new Theme.Card();
        slotsCard.setLayout(new BorderLayout(0, 10));
        slotsCard.setBorder(Theme.padding(14, 16));
        slotsCard.add(slotTitle, BorderLayout.NORTH);
        slotGrid.setOpaque(false);
        JPanel gridHolder = new JPanel(new BorderLayout());
        gridHolder.setOpaque(false);
        gridHolder.add(slotGrid, BorderLayout.NORTH);
        JScrollPane slotScroll = new JScrollPane(gridHolder);
        slotScroll.setBorder(BorderFactory.createEmptyBorder());
        slotScroll.setViewportBorder(BorderFactory.createEmptyBorder());
        gridHolder.setBorder(Theme.padding(2, 2));
        slotScroll.setOpaque(false);
        slotScroll.getViewport().setOpaque(false);
        slotsCard.add(slotScroll, BorderLayout.CENTER);

        // Λόγος επίσκεψης: 3 έτοιμες επιλογές του ιατρού + «Άλλο» με ελεύθερο κείμενο
        JPanel reasonBox = new JPanel(new BorderLayout(0, 8));
        reasonBox.setOpaque(false);
        reasonBox.add(Theme.label("3. Λόγος επίσκεψης *", Font.BOLD, 15, Theme.TEXT), BorderLayout.NORTH);
        JPanel options = new JPanel(new GridLayout(0, 2, 8, 8));
        options.setOpaque(false);
        reasonArea.setLineWrap(true);
        reasonArea.setWrapStyleWord(true);
        reasonArea.setFont(Theme.font(Font.PLAIN, 14));
        reasonArea.setBorder(Theme.padding(6, 8));
        otherScroll = new JScrollPane(reasonArea);
        otherScroll.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Theme.BORDER),
                "Γράψτε τον λόγο της επίσκεψης"));
        otherScroll.setPreferredSize(new java.awt.Dimension(10, 78));
        otherScroll.setVisible(false);
        List<String>[] reasons = new List[1];
        UiSupport.run(this, () -> reasons[0] = doctorService.getVisitReasons(doctor));
        if (reasons[0] != null) {
            for (String r : reasons[0]) {
                ChipButton chip = new ChipButton(r);
                chip.addActionListener(e -> selectReason(r));
                reasonGroup.add(chip);
                options.add(chip);
            }
        }
        reasonBox.add(options, BorderLayout.CENTER);
        reasonBox.add(otherScroll, BorderLayout.SOUTH);
        slotsCard.add(reasonBox, BorderLayout.SOUTH);
        middle.add(slotsCard, BorderLayout.CENTER);
        root.add(middle, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttons.setOpaque(false);
        FlatButton close = new FlatButton("Κλείσιμο", FlatButton.Kind.SECONDARY);
        FlatButton book = new FlatButton("Κράτηση ραντεβού", FlatButton.Kind.PRIMARY);
        buttons.add(close);
        buttons.add(book);
        root.add(buttons, BorderLayout.SOUTH);
        setContentPane(root);

        dayList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadSlots();
            }
        });
        book.addActionListener(e -> book());
        close.addActionListener(e -> dispose());

        loadDays();
        setSize(880, 680);
        setLocationRelativeTo(owner);
    }

    public boolean isBooked() { return booked; }

    /** Το πεδίο κειμένου εμφανίζεται μόνο όταν επιλεγεί «Άλλο». */
    private void selectReason(String reason) {
        selectedReason = reason;
        boolean other = DoctorService.OTHER_REASON.equals(reason);
        otherScroll.setVisible(other);
        getContentPane().revalidate();
        getContentPane().repaint();
        if (other) {
            reasonArea.requestFocusInWindow();
        }
    }

    private void loadDays() {
        dayModel.clear();
        UiSupport.run(this, () -> {
            Map<LocalDate, Integer> overview = service.getAvailabilityOverview(doctor,
                    AppointmentService.BOOKING_HORIZON_DAYS + 1);
            overview.forEach((date, free) -> dayModel.addElement(new DayItem(date, free)));
        });
        for (int i = 0; i < dayModel.size(); i++) {
            if (dayModel.get(i).free > 0) {
                dayList.setSelectedIndex(i);
                return;
            }
        }
        loadSlots();
    }

    private void loadSlots() {
        slotGrid.removeAll();
        slotGroup = new ButtonGroup();
        selectedSlot = null;
        DayItem day = dayList.getSelectedValue();
        if (day == null) {
            slotTitle.setText("2. Ώρα");
        } else {
            slotTitle.setText("2. Ώρα · " + day.date.format(DateUtils.DAY_DATE));
            List<TimeSlot>[] slots = new List[1];
            UiSupport.run(this, () -> slots[0] = service.getAvailableSlots(doctor, day.date));
            if (slots[0] == null || slots[0].isEmpty()) {
                JPanel none = new JPanel(new GridBagLayout());
                none.setOpaque(false);
                none.add(Theme.label("Δεν υπάρχουν ελεύθερες ώρες αυτή την ημέρα.", Font.PLAIN, 14, Theme.MUTED));
                slotGrid.add(none);
            } else {
                for (TimeSlot s : slots[0]) {
                    ChipButton chip = new ChipButton(s.getTime().format(DateUtils.TIME));
                    chip.addActionListener(e -> selectedSlot = s);
                    slotGroup.add(chip);
                    slotGrid.add(chip);
                }
            }
        }
        slotGrid.revalidate();
        slotGrid.repaint();
    }

    private void book() {
        TimeSlot slot = selectedSlot;
        if (slot == null) {
            JOptionPane.showMessageDialog(this, "Επιλέξτε ημέρα και ελεύθερη ώρα.");
            return;
        }
        // Πρώτα ο λόγος: αν λείπει, μένουν ως έχουν η ημέρα και η ώρα που διάλεξε ο ασθενής
        String[] reason = new String[1];
        if (!UiSupport.run(this, () -> reason[0] = doctorService.resolveReason(selectedReason, reasonArea.getText()))) {
            return;
        }
        Appointment[] result = new Appointment[1];
        boolean ok = UiSupport.run(this, () -> result[0] = service.book(patient, doctor, slot.getDate(),
                slot.getTime(), reason[0]));
        if (ok) {
            booked = true;
            JOptionPane.showMessageDialog(this, "Το ραντεβού κλείστηκε!\n"
                    + doctor.getFullName() + "\n" + slot.getDate().format(DateUtils.DAY_DATE)
                    + " στις " + slot.getTime().format(DateUtils.TIME));
            dispose();
        } else {
            int selected = dayList.getSelectedIndex();
            loadDays();
            if (selected >= 0 && selected < dayModel.size()) {
                dayList.setSelectedIndex(selected);
            }
        }
    }

    /** Γραμμή της λίστας ημερών: ημερομηνία και πλήθος ελεύθερων ωρών. */
    private static final class DayItem {
        final LocalDate date;
        final int free;

        DayItem(LocalDate date, int free) {
            this.date = date;
            this.free = free;
        }

        @Override
        public String toString() {
            return date.format(DateUtils.DAY_DATE) + " — " + (free == 0 ? "πλήρες" : free + " ελεύθερες");
        }
    }

    /** Εμφάνιση ημέρας σε δύο γραμμές με χρωματιστή ένδειξη διαθεσιμότητας. */
    private static final class DayRenderer implements ListCellRenderer<DayItem> {
        @Override
        public Component getListCellRendererComponent(JList<? extends DayItem> list, DayItem item, int index,
                                                      boolean selected, boolean focus) {
            JPanel row = new JPanel(new BorderLayout());
            row.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, selected ? 4 : 0, 1, 0,
                            selected ? Theme.PRIMARY : new Color(0xEDF1F6)),
                    Theme.padding(6, selected ? 8 : 12)));
            row.setBackground(selected ? Theme.PRIMARY_LIGHT : Theme.CARD);
            JPanel text = new JPanel();
            text.setOpaque(false);
            text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
            String name = item.date.format(DAY_NAME);
            text.add(Theme.label(Character.toUpperCase(name.charAt(0)) + name.substring(1), Font.BOLD, 14, Theme.TEXT));
            text.add(Theme.label(item.date.format(DateUtils.DATE), Font.PLAIN, 12, Theme.MUTED));
            row.add(text, BorderLayout.CENTER);
            JPanel pillHolder = new JPanel(new java.awt.GridBagLayout());
            pillHolder.setOpaque(false);
            pillHolder.add(item.free == 0
                    ? new Theme.Pill("πλήρες", Theme.MUTED, Theme.NEUTRAL_LIGHT)
                    : new Theme.Pill(item.free + " ελεύθερες", Theme.SUCCESS, Theme.SUCCESS_LIGHT));
            row.add(pillHolder, BorderLayout.EAST);
            return row;
        }
    }
}
