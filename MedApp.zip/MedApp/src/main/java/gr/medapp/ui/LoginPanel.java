package gr.medapp.ui;

import gr.medapp.model.Patient;
import gr.medapp.service.AuthService;
import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/** Οθόνη σύνδεσης ασθενή με ΑΜΚΑ και κωδικό. */
public class LoginPanel extends JPanel {
    private final JTextField amkaField = new JTextField(18);
    private final JPasswordField passwordField = new JPasswordField(18);

    public LoginPanel(MainFrame frame, AuthService authService) {
        super(new BorderLayout());
        JPanel form = new JPanel();
        form.setOpaque(false);
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));

        UiSupport.addFull(form, UiSupport.title("Σύνδεση"));
        form.add(Box.createVerticalStrut(4));
        UiSupport.addFull(form, Theme.label("Μπείτε με τον ΑΜΚΑ και τον κωδικό σας", Font.PLAIN, 14, Theme.MUTED));
        form.add(Box.createVerticalStrut(22));
        UiSupport.addField(form, "ΑΜΚΑ", amkaField);
        UiSupport.addField(form, "Κωδικός", passwordField);
        form.add(Box.createVerticalStrut(6));

        FlatButton login = new FlatButton("Σύνδεση", FlatButton.Kind.PRIMARY);
        UiSupport.addFull(form, login);
        form.add(Box.createVerticalStrut(10));
        FlatButton register = new FlatButton("Δημιουργία λογαριασμού", FlatButton.Kind.SECONDARY);
        UiSupport.addFull(form, register);
        form.add(Box.createVerticalStrut(18));

        JLabel hint = Theme.label("<html>Δοκιμαστικός λογαριασμός:<br><b>01019000015</b> / <b>demo123</b></html>",
                Font.PLAIN, 12, Theme.MUTED);
        UiSupport.addFull(form, hint);

        add(Theme.splitScreen(Theme.brandPanel("Κλείστε ραντεβού με τον ιατρό σας γρήγορα, χωρίς τηλεφωνήματα.",
                "Διαλέξτε ειδικότητα και περιοχή", "Δείτε τις ελεύθερες ώρες", "Κλείστε το ραντεβού σας"), form));

        login.addActionListener(e -> {
            Patient[] result = new Patient[1];
            if (UiSupport.run(this, () -> result[0] = authService.login(amkaField.getText(), passwordField.getPassword()))) {
                frame.showHome(result[0]);
            }
        });
        passwordField.addActionListener(e -> login.doClick());
        amkaField.addActionListener(e -> passwordField.requestFocusInWindow());
        register.addActionListener(e -> frame.showRegister());
    }

    void reset() {
        amkaField.setText("");
        passwordField.setText("");
    }
}
