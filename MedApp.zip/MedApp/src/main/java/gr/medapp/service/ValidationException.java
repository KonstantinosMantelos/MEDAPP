package gr.medapp.service;

/** Παραβίαση επιχειρησιακού κανόνα· το μήνυμα εμφανίζεται στον χρήστη. */
public class ValidationException extends RuntimeException {
    public ValidationException(String message) { super(message); }
}
