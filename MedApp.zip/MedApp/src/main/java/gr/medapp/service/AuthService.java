package gr.medapp.service;

import gr.medapp.dao.PatientDAO;
import gr.medapp.model.Patient;
import gr.medapp.util.AmkaValidator;
import gr.medapp.util.PasswordHasher;
import java.time.Clock;
import java.time.LocalDateTime;
import java.util.Optional;

/** Εγγραφή και σύνδεση ασθενών με ΑΜΚΑ και κωδικό. */
public class AuthService {
    public static final int MIN_PASSWORD_LENGTH = 6;

    private final PatientDAO patientDAO;
    private final Clock clock;

    public AuthService(PatientDAO patientDAO, Clock clock) {
        this.patientDAO = patientDAO;
        this.clock = clock;
    }

    public Patient register(String amka, String firstName, String lastName, String phone, String email,
                            char[] password, char[] confirmPassword) {
        amka = trim(amka);
        if (!AmkaValidator.isValid(amka)) {
            throw new ValidationException("Ο ΑΜΚΑ δεν είναι έγκυρος (11 ψηφία με σωστό ψηφίο ελέγχου).");
        }
        if (trim(firstName).isEmpty() || trim(lastName).isEmpty()) {
            throw new ValidationException("Συμπληρώστε όνομα και επώνυμο.");
        }
        if (!trim(phone).isEmpty() && !trim(phone).matches("\\d{10}")) {
            throw new ValidationException("Το τηλέφωνο πρέπει να έχει 10 ψηφία.");
        }
        if (!trim(email).isEmpty() && !trim(email).matches("[^@\\s]+@[^@\\s]+\\.[^@\\s]+")) {
            throw new ValidationException("Το email δεν είναι έγκυρο.");
        }
        if (password == null || password.length < MIN_PASSWORD_LENGTH) {
            throw new ValidationException("Ο κωδικός πρέπει να έχει τουλάχιστον " + MIN_PASSWORD_LENGTH + " χαρακτήρες.");
        }
        if (!java.util.Arrays.equals(password, confirmPassword)) {
            throw new ValidationException("Οι κωδικοί δεν ταιριάζουν.");
        }
        if (patientDAO.exists(amka)) {
            throw new ValidationException("Υπάρχει ήδη λογαριασμός με αυτόν τον ΑΜΚΑ.");
        }
        String salt = PasswordHasher.newSalt();
        Patient patient = new Patient(amka, trim(firstName), trim(lastName), trim(phone), trim(email),
                PasswordHasher.hash(password, salt), salt, LocalDateTime.now(clock));
        patientDAO.insert(patient);
        return patient;
    }

    public Patient login(String amka, char[] password) {
        Optional<Patient> found = patientDAO.findByAmka(trim(amka));
        if (found.isEmpty() || password == null
                || !PasswordHasher.verify(password, found.get().getSalt(), found.get().getPasswordHash())) {
            throw new ValidationException("Λάθος ΑΜΚΑ ή κωδικός.");
        }
        return found.get();
    }

    private static String trim(String s) { return s == null ? "" : s.trim(); }
}
