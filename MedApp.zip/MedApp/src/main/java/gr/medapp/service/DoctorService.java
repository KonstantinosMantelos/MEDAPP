package gr.medapp.service;

import gr.medapp.dao.DoctorDAO;
import gr.medapp.dao.VisitReasonDAO;
import gr.medapp.model.Doctor;
import gr.medapp.util.DateUtils;
import java.text.Collator;
import java.util.List;

/** Αναζήτηση ιατρών ανά ειδικότητα και περιοχή. */
public class DoctorService {
    /** Η επιλογή που επιτρέπει στον ασθενή να γράψει δικό του λόγο. */
    public static final String OTHER_REASON = "Άλλο";

    private final DoctorDAO doctorDAO;
    private final VisitReasonDAO visitReasonDAO;
    private final Collator greek = Collator.getInstance(DateUtils.GREEK);

    public DoctorService(DoctorDAO doctorDAO, VisitReasonDAO visitReasonDAO) {
        this.doctorDAO = doctorDAO;
        this.visitReasonDAO = visitReasonDAO;
    }

    /** Οι 3 προκαθορισμένοι λόγοι επίσκεψης του ιατρού και στο τέλος η επιλογή «Άλλο». */
    public List<String> getVisitReasons(Doctor doctor) {
        List<String> list = new java.util.ArrayList<>(visitReasonDAO.findByDoctor(doctor.getAmka()));
        list.add(OTHER_REASON);
        return list;
    }

    /**
     * Ο λόγος που θα αποθηκευτεί: η επιλογή από τη λίστα ή, αν επιλέχθηκε «Άλλο»,
     * το κείμενο που έγραψε ο ασθενής.
     */
    public String resolveReason(String selectedOption, String otherText) {
        if (selectedOption == null) {
            throw new ValidationException("Επιλέξτε λόγο επίσκεψης.");
        }
        if (OTHER_REASON.equals(selectedOption)) {
            String t = otherText == null ? "" : otherText.trim();
            if (t.isEmpty()) {
                throw new ValidationException("Γράψτε τον λόγο της επίσκεψης στο πεδίο «Άλλο».");
            }
            return t;
        }
        return selectedOption;
    }

    public List<String> getSpecialties() {
        List<String> list = doctorDAO.findAllSpecialties();
        list.sort(greek);
        return list;
    }

    public List<String> getAreas(String specialty) {
        List<String> list = doctorDAO.findAreasBySpecialty(specialty);
        list.sort(greek);
        return list;
    }

    /** Ιατροί της ειδικότητας σε όλες τις επιλεγμένες περιοχές μαζί. */
    public List<Doctor> findDoctors(String specialty, List<String> areas) {
        if (specialty == null) {
            throw new ValidationException("Επιλέξτε ειδικότητα.");
        }
        if (areas == null || areas.isEmpty()) {
            throw new ValidationException("Επιλέξτε τουλάχιστον μία περιοχή.");
        }
        return doctorDAO.findBySpecialtyAndAreas(specialty, areas);
    }
}
