package gr.medapp.service;

import gr.medapp.dao.AppointmentDAO;
import gr.medapp.dao.DataAccessException;
import gr.medapp.dao.WorkingHoursDAO;
import gr.medapp.model.Appointment;
import gr.medapp.model.AppointmentStatus;
import gr.medapp.model.AvailabilityLevel;
import gr.medapp.model.Doctor;
import gr.medapp.model.Patient;
import gr.medapp.model.TimeSlot;
import gr.medapp.model.WorkingHours;
import gr.medapp.util.DateUtils;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Διαθεσιμότητα ιατρών, κράτηση, ακύρωση και προβολή ραντεβού. */
public class AppointmentService {
    /** Πόσες ημέρες μπροστά μπορεί να κλειστεί ραντεβού. */
    public static final int BOOKING_HORIZON_DAYS = 30;
    public static final int MAX_REASON_LENGTH = 255;
    /** Κάθε ραντεβού (εξέταση + διάλειμμα) δεσμεύει τον ιατρό έως τόσα λεπτά από την ώρα έναρξής του. */
    public static final int MAX_APPOINTMENT_MINUTES = 90;
    /** Μέγιστος αριθμός ενεργών ραντεβού ενός ιατρού την ίδια ημέρα. */
    public static final int MAX_APPOINTMENTS_PER_DAY = 4;
    /** Πράσινη διαθεσιμότητα: τουλάχιστον τόσο ποσοστό ελεύθερων ωρών... */
    public static final double GOOD_FREE_RATIO = 0.4;
    /** ...και ελεύθερες ώρες σε τουλάχιστον τόσες διαφορετικές ημέρες... */
    public static final int GOOD_FREE_DAYS = 3;
    /** ...και τουλάχιστον τόσες ελεύθερες ώρες συνολικά (αλλιώς οι επιλογές είναι λιγοστές). */
    public static final int GOOD_FREE_SLOTS = 20;

    private final AppointmentDAO appointmentDAO;
    private final WorkingHoursDAO workingHoursDAO;
    private final Clock clock;

    public AppointmentService(AppointmentDAO appointmentDAO, WorkingHoursDAO workingHoursDAO, Clock clock) {
        this.appointmentDAO = appointmentDAO;
        this.workingHoursDAO = workingHoursDAO;
        this.clock = clock;
    }

    public LocalDateTime now() { return LocalDateTime.now(clock); }

    /** Όλες οι χρονοθυρίδες του ιατρού μια ημέρα, σημειωμένες ως ελεύθερες ή κλεισμένες. */
    public List<TimeSlot> getSlots(Doctor doctor, LocalDate date) {
        return buildSlots(workingHoursDAO.findByDoctor(doctor.getAmka()), doctor, date);
    }

    /** Μόνο οι ελεύθερες χρονοθυρίδες μιας ημέρας. */
    public List<TimeSlot> getAvailableSlots(Doctor doctor, LocalDate date) {
        List<TimeSlot> free = new ArrayList<>();
        for (TimeSlot s : getSlots(doctor, date)) {
            if (s.isAvailable()) {
                free.add(s);
            }
        }
        return free;
    }

    /** Πλήθος ελεύθερων ραντεβού ανά ημέρα για τις επόμενες {@code days} ημέρες (μόνο ημέρες ιατρείου). */
    public Map<LocalDate, Integer> getAvailabilityOverview(Doctor doctor, int days) {
        List<WorkingHours> hours = workingHoursDAO.findByDoctor(doctor.getAmka());
        Map<LocalDate, Integer> overview = new LinkedHashMap<>();
        LocalDate today = now().toLocalDate();
        for (int i = 0; i < days; i++) {
            LocalDate date = today.plusDays(i);
            if (hoursFor(hours, date).isEmpty()) {
                continue;
            }
            int free = 0;
            for (TimeSlot s : buildSlots(hours, doctor, date)) {
                if (s.isAvailable()) {
                    free++;
                }
            }
            overview.put(date, free);
        }
        return overview;
    }

    /** Η πρώτη ελεύθερη χρονοθυρίδα του ιατρού μέσα στις επόμενες {@value #BOOKING_HORIZON_DAYS} ημέρες. */
    public java.util.Optional<TimeSlot> findNextAvailable(Doctor doctor) {
        List<WorkingHours> hours = workingHoursDAO.findByDoctor(doctor.getAmka());
        LocalDate today = now().toLocalDate();
        for (int i = 0; i <= BOOKING_HORIZON_DAYS; i++) {
            LocalDate date = today.plusDays(i);
            if (hoursFor(hours, date).isEmpty()) {
                continue;
            }
            for (TimeSlot s : buildSlots(hours, doctor, date)) {
                if (s.isAvailable()) {
                    return java.util.Optional.of(s);
                }
            }
        }
        return java.util.Optional.empty();
    }

    /** Επίπεδο διαθεσιμότητας του ιατρού για τις επόμενες {@value #BOOKING_HORIZON_DAYS} ημέρες. */
    public AvailabilityLevel getAvailabilityLevel(Doctor doctor) {
        List<WorkingHours> hours = workingHoursDAO.findByDoctor(doctor.getAmka());
        LocalDate today = now().toLocalDate();
        int total = 0;
        int free = 0;
        int freeDays = 0;
        for (int i = 0; i <= BOOKING_HORIZON_DAYS; i++) {
            LocalDate date = today.plusDays(i);
            if (hoursFor(hours, date).isEmpty()) {
                continue;
            }
            int freeToday = 0;
            for (TimeSlot s : buildSlots(hours, doctor, date)) {
                if (!LocalDateTime.of(date, s.getTime()).isAfter(now())) {
                    continue;   // οι ώρες που πέρασαν δεν μετράνε
                }
                total++;
                if (s.isAvailable()) {
                    freeToday++;
                }
            }
            free += freeToday;
            if (freeToday > 0) {
                freeDays++;
            }
        }
        return classify(total, free, freeDays);
    }

    /**
     * Κανόνας χρωμάτων: πράσινο αν οι ελεύθερες ώρες είναι ≥ 20, ≥ 40% του ωραρίου και σε ≥ 3 ημέρες·
     * κίτρινο αν υπάρχουν αλλά είναι λιγοστές· κόκκινο αν δεν υπάρχει καμία.
     */
    public static AvailabilityLevel classify(int totalSlots, int freeSlots, int freeDays) {
        if (freeSlots == 0) {
            return AvailabilityLevel.NONE;
        }
        if (freeSlots >= GOOD_FREE_SLOTS && freeSlots >= GOOD_FREE_RATIO * totalSlots
                && freeDays >= GOOD_FREE_DAYS) {
            return AvailabilityLevel.AVAILABLE;
        }
        return AvailabilityLevel.PARTIAL;
    }

    /** Δύο ραντεβού συγκρούονται αν απέχουν λιγότερο από {@value #MAX_APPOINTMENT_MINUTES} λεπτά. */
    static boolean overlaps(LocalTime a, LocalTime b) {
        return Math.abs(java.time.Duration.between(a, b).toMinutes()) < MAX_APPOINTMENT_MINUTES;
    }

    private static boolean overlapsAny(LocalTime t, List<LocalTime> booked) {
        for (LocalTime b : booked) {
            if (overlaps(t, b)) {
                return true;
            }
        }
        return false;
    }

    public Appointment book(Patient patient, Doctor doctor, LocalDate date, LocalTime time, String reason) {
        String r = reason == null ? "" : reason.trim();
        if (r.isEmpty()) {
            throw new ValidationException("Συμπληρώστε τον λόγο του ραντεβού.");
        }
        if (r.length() > MAX_REASON_LENGTH) {
            throw new ValidationException("Ο λόγος δεν μπορεί να ξεπερνά τους " + MAX_REASON_LENGTH + " χαρακτήρες.");
        }
        LocalDateTime when = LocalDateTime.of(date, time);
        if (!when.isAfter(now())) {
            throw new ValidationException("Δεν μπορείτε να κλείσετε ραντεβού σε παρελθοντική ώρα.");
        }
        if (date.isAfter(now().toLocalDate().plusDays(BOOKING_HORIZON_DAYS))) {
            throw new ValidationException("Τα ραντεβού κλείνονται έως " + BOOKING_HORIZON_DAYS + " ημέρες μπροστά.");
        }
        if (appointmentDAO.findBookedTimes(doctor.getAmka(), date).size() >= MAX_APPOINTMENTS_PER_DAY) {
            throw new ValidationException("Ο ιατρός έχει ήδη " + MAX_APPOINTMENTS_PER_DAY
                    + " ραντεβού αυτή την ημέρα (το μέγιστο). Διαλέξτε άλλη ημέρα.");
        }
        boolean free = false;
        for (TimeSlot s : getSlots(doctor, date)) {
            if (s.getTime().equals(time)) {
                free = s.isAvailable();
                if (!free) {
                    throw new ValidationException("Η ώρα " + time.format(DateUtils.TIME) + " δεν είναι διαθέσιμη: "
                            + "κάθε ραντεβού δεσμεύει τον ιατρό έως 1,5 ώρα. Διαλέξτε άλλη.");
                }
            }
        }
        if (!free) {
            throw new ValidationException("Η ώρα αυτή δεν ανήκει στο ωράριο του ιατρού.");
        }
        if (overlapsAny(time, appointmentDAO.findPatientBookedTimes(patient.getAmka(), date))) {
            throw new ValidationException("Έχετε ήδη άλλο ραντεβού σε απόσταση μικρότερη από 1,5 ώρα.");
        }
        Appointment appointment = new Appointment(0, patient.getAmka(), doctor, date, time, r,
                AppointmentStatus.ACTIVE, now());
        try {
            appointmentDAO.insert(appointment);
        } catch (DataAccessException e) {
            // Π.χ. παραβίαση μοναδικότητας αν άλλος χρήστης την πρόλαβε ταυτόχρονα
            throw new ValidationException("Η κράτηση δεν ολοκληρώθηκε: η ώρα δεν είναι πια διαθέσιμη.");
        }
        return appointment;
    }

    public void cancel(Patient patient, int appointmentId) {
        Appointment a = appointmentDAO.findById(appointmentId)
                .orElseThrow(() -> new ValidationException("Το ραντεβού δεν βρέθηκε."));
        if (!a.getPatientAmka().equals(patient.getAmka())) {
            throw new ValidationException("Μπορείτε να ακυρώσετε μόνο δικά σας ραντεβού.");
        }
        if (!a.isCancellable(now())) {
            throw new ValidationException("Το ραντεβού είναι " + a.getEffectiveStatus(now()).getLabel().toLowerCase()
                    + " και δεν μπορεί να ακυρωθεί.");
        }
        a.cancel();
        appointmentDAO.updateStatus(a.getId(), a.getStatus());
    }

    /**
     * Μαζική ακύρωση: ελέγχει πρώτα ότι ΟΛΑ τα ραντεβού επιτρέπεται να ακυρωθούν
     * και μόνο τότε τα ακυρώνει (όλα ή κανένα). Επιστρέφει πόσα ακυρώθηκαν.
     */
    public int cancelAll(Patient patient, List<Integer> appointmentIds) {
        if (appointmentIds == null || appointmentIds.isEmpty()) {
            throw new ValidationException("Επιλέξτε τουλάχιστον ένα ραντεβού για ακύρωση.");
        }
        List<Appointment> toCancel = new ArrayList<>();
        for (int id : new java.util.LinkedHashSet<>(appointmentIds)) {
            Appointment a = appointmentDAO.findById(id)
                    .orElseThrow(() -> new ValidationException("Το ραντεβού " + id + " δεν βρέθηκε."));
            if (!a.getPatientAmka().equals(patient.getAmka())) {
                throw new ValidationException("Μπορείτε να ακυρώσετε μόνο δικά σας ραντεβού.");
            }
            if (!a.isCancellable(now())) {
                throw new ValidationException("Το ραντεβού της " + a.getDate().format(DateUtils.DATE) + " "
                        + a.getTime().format(DateUtils.TIME) + " δεν μπορεί να ακυρωθεί. Δεν ακυρώθηκε κανένα.");
            }
            toCancel.add(a);
        }
        for (Appointment a : toCancel) {
            a.cancel();
            appointmentDAO.updateStatus(a.getId(), a.getStatus());
        }
        return toCancel.size();
    }

    /** Ραντεβού του ασθενή στην εβδομάδα (Δευτέρα–Κυριακή) που περιέχει την ημέρα. */
    public List<Appointment> getWeeklyAppointments(Patient patient, LocalDate anyDayOfWeek) {
        return appointmentDAO.findByPatientAndPeriod(patient.getAmka(),
                DateUtils.startOfWeek(anyDayOfWeek), DateUtils.endOfWeek(anyDayOfWeek));
    }

    /** Ραντεβού του ασθενή στον μήνα. */
    public List<Appointment> getMonthlyAppointments(Patient patient, YearMonth month) {
        return appointmentDAO.findByPatientAndPeriod(patient.getAmka(), month.atDay(1), month.atEndOfMonth());
    }

    private List<TimeSlot> buildSlots(List<WorkingHours> hours, Doctor doctor, LocalDate date) {
        List<LocalTime> booked = appointmentDAO.findBookedTimes(doctor.getAmka(), date);
        boolean dayFull = booked.size() >= MAX_APPOINTMENTS_PER_DAY;
        LocalDateTime now = now();
        List<TimeSlot> slots = new ArrayList<>();
        for (WorkingHours wh : hoursFor(hours, date)) {
            for (LocalTime t : wh.generateSlotTimes()) {
                boolean available = !dayFull && !overlapsAny(t, booked) && LocalDateTime.of(date, t).isAfter(now);
                slots.add(new TimeSlot(date, t, available));
            }
        }
        return slots;
    }

    private static List<WorkingHours> hoursFor(List<WorkingHours> hours, LocalDate date) {
        List<WorkingHours> result = new ArrayList<>();
        for (WorkingHours wh : hours) {
            if (wh.getDayOfWeek() == date.getDayOfWeek()) {
                result.add(wh);
            }
        }
        return result;
    }
}
